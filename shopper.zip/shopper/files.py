"""Fotos privadas de compras, unificadas y etiquetadas por propósito."""
import hashlib
import io
import warnings

from PIL import Image, UnidentifiedImageError
from werkzeug.utils import secure_filename

from .db import get_db
from .domain import BusinessError
from .services import audit, owned, rows

MAX_FILE = 8 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 25_000_000
TABLES = {'photo': 'purchase_photos'}


def validate(upload):
    data = upload.read(MAX_FILE + 1)
    if not data or len(data) > MAX_FILE:
        raise BusinessError('Cada foto debe tener entre 1 byte y 8 MB.')
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            image = Image.open(io.BytesIO(data))
            mime = {'JPEG': 'image/jpeg', 'PNG': 'image/png', 'WEBP': 'image/webp'}.get(image.format)
            if not mime or getattr(image, 'n_frames', 1) != 1:
                raise BusinessError('Admite fotos JPEG, PNG o WebP estáticas; no GIF, SVG, PDF ni animaciones.')
            image.verify()
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise BusinessError('La foto no es válida o supera 25 millones de píxeles.') from None
    return data, mime, secure_filename(upload.filename)[:180] or 'foto'


def read_uploads(uploads, form):
    upload_list = uploads.getlist('photo_file')
    kinds = form.getlist('photo_kind')
    if not any(upload.filename for upload in upload_list):
        return []
    if len(upload_list) != len(kinds):
        raise BusinessError('Cada foto debe tener una etiqueta Producto o Factura.')
    candidates = [(kind, upload) for kind, upload in zip(kinds, upload_list) if upload.filename]
    if len(candidates) > 12:
        raise BusinessError('Máximo 12 fotos por operación.')
    result = []
    for kind, upload in candidates:
        if kind not in ('product', 'invoice'):
            raise BusinessError('Etiqueta de foto no válida.')
        data, mime, name = validate(upload)
        result.append({'kind': kind, 'data': data, 'mime': mime, 'name': name})
    return result


def attach(owner, purchase_id, uploads, form):
    for image in read_uploads(uploads, form):
        kind, data, mime, name = image['kind'], image['data'], image['mime'], image['name']
        file_id = get_db().execute(
            '''INSERT INTO purchase_photos
               (owner_id,purchase_id,kind,original_name,mime,size,sha256,original,extraction_status)
               VALUES (?,?,?,?,?,?,?,?,?)''',
            (owner, purchase_id, kind, name, mime, len(data), hashlib.sha256(data).hexdigest(), data,
             'manual' if kind == 'invoice' else 'no_aplica')
        ).lastrowid
        audit(owner, 'photo', file_id, 'adjuntada', {'purchase': purchase_id, 'kind': kind, 'name': name})


def list_files(owner, purchase_id):
    return rows(
        '''SELECT id,owner_id,purchase_id,kind,original_name,mime,size,sha256,
                  extraction_status,created_at,removed_at
           FROM purchase_photos WHERE owner_id=? AND purchase_id=? ORDER BY id''',
        (owner, purchase_id),
    )


def remove(owner, kind, file_id, reason):
    if kind != 'photo':
        raise BusinessError('Archivo desconocido.')
    photo = owned('purchase_photos', file_id, owner)
    if photo['removed_at']:
        raise BusinessError('La foto ya fue retirada de la vista activa.')
    get_db().execute(
        'UPDATE purchase_photos SET removed_at=CURRENT_TIMESTAMP WHERE id=? AND owner_id=?',
        (file_id, owner),
    )
    audit(owner, 'photo', file_id, 'retirada', {'reason': reason, 'purchase': photo['purchase_id']})
    return photo['purchase_id']
