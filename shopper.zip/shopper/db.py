import sqlite3
from pathlib import Path
from flask import current_app, g


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(current_app.config['DATABASE'], timeout=15)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys=ON')
    return g.db


def init_db():
    db = get_db()
    version = db.execute('PRAGMA user_version').fetchone()[0]
    if version not in (0, 1, 2, 3, 4, 5, 6):
        raise RuntimeError('Versión de base de datos no compatible. No se modificó el esquema.')
    if version == 0:
        db.executescript(Path(__file__).with_name('schema.sql').read_text(encoding='utf-8'))
    if version in (0, 1):
        from .migrations import migrate_v2
        migrate_v2(db, current_app.config['DATABASE'], backup=version == 1)
        version = 2
    if version == 2:
        from .migrations import migrate_v3
        migrate_v3(db, current_app.config['DATABASE'], backup=True)
        version = 3
    if version == 3:
        from .migrations import migrate_v4
        migrate_v4(db, current_app.config['DATABASE'], backup=True)
        version = 4
    if version == 4:
        from .migrations import migrate_v5
        migrate_v5(db, current_app.config['DATABASE'], backup=True)
        version = 5
    if version == 5:
        from .migrations import migrate_v6
        migrate_v6(db, current_app.config['DATABASE'], backup=True)
    db.execute('PRAGMA journal_mode=WAL')


def close_db(error=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()
