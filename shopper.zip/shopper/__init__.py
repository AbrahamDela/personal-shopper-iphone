import os
import secrets
import socket
import sqlite3
from datetime import date, timedelta
from pathlib import Path
from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.exceptions import SecurityError
from werkzeug.security import check_password_hash, generate_password_hash
from . import services as svc
from .db import close_db, get_db, init_db
from .domain import BusinessError, integer, money, rate, text, valid_date


def trusted_hosts():
    hosts={'localhost','127.0.0.1'}
    try:
        hosts.update(info[4][0] for info in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET))
    except OSError:
        pass
    hosts.update(value.strip() for value in os.environ.get('APP_TRUSTED_HOSTS','').split(',') if value.strip())
    return sorted(hosts)


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    secret = os.environ.get('SECRET_KEY')
    if not secret:
        secret_path = Path(app.instance_path) / 'secret.key'
        if not secret_path.exists():
            try:
                with secret_path.open('x') as f:
                    f.write(secrets.token_hex(32))
            except FileExistsError:
                pass
        secret = secret_path.read_text().strip()
    app.config.update(SECRET_KEY=secret, DATABASE=os.environ.get('DATABASE_PATH', str(Path(app.instance_path) / 'shopper.sqlite')),
                      GEMINI_API_KEY=os.environ.get('GEMINI_API_KEY') or os.environ.get('GOOGLE_API_KEY'),
                      GEMINI_MODEL=os.environ.get('GEMINI_MODEL','gemini-flash-latest'),
                      SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
                      SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE') == '1',
                      PERMANENT_SESSION_LIFETIME=timedelta(hours=8), MAX_CONTENT_LENGTH=48*1024*1024, MAX_FORM_MEMORY_SIZE=1024*1024, MAX_FORM_PARTS=2000,
                      TRUSTED_HOSTS=trusted_hosts())
    if test_config:
        app.config.update(test_config)
    app.teardown_appcontext(close_db)
    with app.app_context():
        init_db()

    @app.template_filter('cash')
    def cash(value):
        sign = '-' if value < 0 else ''
        value = abs(int(value))
        return f'{sign}{value // 100:,}.{value % 100:02d}'

    @app.context_processor
    def context():
        if 'csrf' not in session:
            session['csrf'] = secrets.token_hex(32)
        return dict(today=date.today().isoformat(), csrf=session['csrf'], currencies=['USD'])

    @app.before_request
    def protect():
        if request.routing_exception is not None:
            return None
        g.user = None
        if session.get('user_id'):
            g.user = get_db().execute('SELECT id,name,email FROM users WHERE id=?', (session['user_id'],)).fetchone()
        if request.endpoint not in ('login','register','static') and not g.user:
            return redirect(url_for('login'))
        if request.method == 'POST':
            if request.endpoint == 'backup_import':
                from .backup import MAX_BACKUP_BYTES
                request.max_content_length = MAX_BACKUP_BYTES + 1024 * 1024
            supplied = request.form.get('csrf', '')
            if not supplied or not secrets.compare_digest(supplied.encode(), session.get('csrf', '').encode()):
                abort(400, 'El formulario venció. Recarga la página e inténtalo de nuevo.')
            if request.endpoint != 'analyze_purchase_photos':
                get_db().execute('BEGIN IMMEDIATE')

    @app.after_request
    def finish(response):
        if 'db' in g and g.db.in_transaction:
            if response.status_code < 400:
                g.db.commit()
            else:
                g.db.rollback()
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; form-action 'self'; base-uri 'self'"
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.errorhandler(BusinessError)
    def business_error(error):
        return render_template('error.html', message=str(error)), 400

    @app.errorhandler(SecurityError)
    def untrusted_host(error):
        return 'Solicitud no válida.', 400

    @app.errorhandler(sqlite3.IntegrityError)
    def integrity_error(error):
        return render_template('error.html', message='No se guardó la operación. Existe un registro duplicado o una restricción de integridad. Revisa los datos.'), 400

    @app.errorhandler(400)
    @app.errorhandler(404)
    @app.errorhandler(413)
    def http_error(error):
        message = error.description if error.code == 400 else 'Página no disponible.'
        if error.code == 413:
            message = ('El archivo de respaldo es demasiado grande. El límite es 512 MiB.'
                       if request.endpoint == 'backup_import' else 'El formulario supera el límite de tamaño permitido.')
        return render_template('error.html', message=message), error.code

    @app.route('/registro', methods=['GET','POST'])
    def register():
        if request.method == 'POST':
            name = text(request.form.get('name'))
            email = text(request.form.get('email'), 'Correo').lower()
            password = request.form.get('password','')
            if '@' not in email or not 10 <= len(password) <= 128:
                raise BusinessError('Introduce un correo válido y una contraseña de 10 a 128 caracteres.')
            if get_db().execute('SELECT id FROM users WHERE email=?', (email,)).fetchone():
                raise BusinessError('Ya existe una cuenta con ese correo.')
            cur = get_db().execute('INSERT INTO users(name,email,password_hash) VALUES (?,?,?)', (name,email,generate_password_hash(password)))
            get_db().execute("INSERT INTO purchase_accounts(owner_id,name,kind,last4) VALUES (?,'Efectivo','cash','')",(cur.lastrowid,))
            session.clear()
            session.update(user_id=cur.lastrowid, csrf=secrets.token_hex(32))
            session.permanent = True
            flash('Tu perfil de personal shopper está listo. Crea tu primera jornada.', 'success')
            return redirect(url_for('dashboard'))
        return render_template('auth.html', registering=True)

    @app.route('/login', methods=['GET','POST'])
    def login():
        if request.method == 'POST':
            email = request.form.get('email','').strip().lower()
            user = get_db().execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
            password = request.form.get('password','')
            if not user or len(password)>128 or not check_password_hash(user['password_hash'],password):
                raise BusinessError('Correo o contraseña incorrectos.')
            session.clear()
            session.update(user_id=user['id'], csrf=secrets.token_hex(32))
            session.permanent = True
            return redirect(url_for('dashboard'))
        return render_template('auth.html', registering=False)

    @app.post('/salir')
    def logout():
        session.clear()
        return redirect(url_for('login'))

    from .views import register_views
    register_views(app)
    return app
