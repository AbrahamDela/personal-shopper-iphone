"""Respaldo JSON versionado de una cuenta, con restauración transaccional."""
import base64
import copy
import hashlib
import json
from datetime import datetime, timezone

from .db import get_db
from .domain import BusinessError

FORMAT = 'personal-shopper-account'
VERSION = 6
TABLES = (
    'clients', 'journeys', 'products', 'stores', 'accounts', 'purchase_accounts', 'billings',
    'purchases', 'purchase_account_assignments', 'items', 'receipts', 'receipt_account_assignments', 'allocations', 'deliveries',
    'cash_applications', 'boxes', 'local_shipments', 'local_items',
    'purchase_photos', 'audit',
)
INSERT_ORDER = TABLES
DELETE_ORDER = (
    'audit', 'purchase_photos', 'invoice_documents', 'product_photos',
    'local_items', 'local_shipments', 'boxes', 'cash_applications', 'deliveries',
    'allocations', 'receipt_account_assignments', 'receipts', 'items', 'purchase_account_assignments', 'purchases', 'billings',
    'purchase_accounts', 'accounts',
    'products', 'stores', 'clients', 'journeys',
)
FOREIGN_KEYS = {
    'billings': {'journey_id': 'journeys', 'client_id': 'clients'},
    'purchases': {'journey_id': 'journeys', 'client_id': 'clients', 'store_id': 'stores', 'billing_id': 'billings'},
    'purchase_account_assignments': {'purchase_id': 'purchases', 'account_id': 'purchase_accounts'},
    'items': {'purchase_id': 'purchases', 'product_id': 'products'},
    'receipts': {'client_id': 'clients', 'account_id': 'accounts'},
    'receipt_account_assignments': {'receipt_id': 'receipts', 'account_id': 'purchase_accounts'},
    'allocations': {'client_id': 'clients', 'receipt_id': 'receipts', 'purchase_id': 'purchases'},
    'deliveries': {'item_id': 'items'},
    'cash_applications': {'client_id': 'clients', 'receipt_id': 'receipts', 'billing_id': 'billings'},
    'boxes': {'journey_id': 'journeys'},
    'local_shipments': {'billing_id': 'billings'},
    'local_items': {'shipment_id': 'local_shipments', 'item_id': 'items', 'delivery_id': 'deliveries'},
    'purchase_photos': {'purchase_id': 'purchases'},
}
AUDIT_ENTITY_TABLE = {
    'client': 'clients', 'journey': 'journeys', 'purchase': 'purchases',
    'billing': 'billings', 'receipt': 'receipts', 'delivery': 'deliveries',
    'application': 'cash_applications', 'box': 'boxes', 'local': 'local_shipments',
    'photo': 'purchase_photos', 'purchase_account': 'purchase_accounts',
}


def _encode(value):
    if isinstance(value, bytes):
        return {'encoding': 'base64', 'data': base64.b64encode(value).decode('ascii')}
    return value


def _decode(value):
    if isinstance(value, dict) and value.get('encoding') == 'base64' and set(value) == {'encoding', 'data'}:
        try:
            return base64.b64decode(value['data'], validate=True)
        except (ValueError, TypeError):
            raise BusinessError('El respaldo contiene un archivo con codificación inválida.') from None
    return value


def export_account(owner):
    db = get_db()
    user = dict(db.execute('SELECT * FROM users WHERE id=?', (owner,)).fetchone())
    account = {key: user[key] for key in ('name', 'email', 'created_at', 'threshold', 'low_rate', 'high_rate', 'default_tax4')}
    tables = {}
    for table in TABLES:
        exported = []
        for source in db.execute(f'SELECT * FROM {table} WHERE owner_id=? ORDER BY id', (owner,)).fetchall():
            row = {key: _encode(source[key]) for key in source.keys() if key != 'owner_id'}
            exported.append(row)
        tables[table] = exported
    return {
        'format': FORMAT,
        'version': VERSION,
        'exported_at': datetime.now(timezone.utc).isoformat(),
        'currency': 'USD',
        'account': account,
        'tables': tables,
    }


def _columns(table):
    return {row['name'] for row in get_db().execute(f'PRAGMA table_info({table})')}


def _upgrade_purchase_rates(tables):
    items_by_purchase = {}
    for item in tables.get('items', []):
        if not item.get('archived'):
            items_by_purchase.setdefault(item.get('purchase_id'), []).append(item)
    purchases_by_billing = {}
    for purchase in tables.get('purchases', []):
        purchases_by_billing.setdefault(purchase.get('billing_id'), []).append(purchase)
    for billing in tables.get('billings', []):
        purchases = purchases_by_billing.get(billing.get('id'), [])
        bases = []
        for purchase in purchases:
            if purchase.get('voided_at'):
                continue
            subtotal = sum(item.get('quantity', 0) * item.get('price', 0)
                           for item in items_by_purchase.get(purchase.get('id'), []))
            tax = (subtotal * purchase.get('tax_rate4', 0) + 500000) // 1000000
            bases.append(subtotal + tax)
        base = sum(bases)
        mode = billing.get('mode')
        if mode == 'legacy':
            continue
        if mode == 'rate':
            commission_rate = billing.get('custom_rate', 0)
        elif mode == 'amount':
            commission_rate = min(10000, (billing.get('custom_amount', 0) * 10000 + base // 2) // base) if base else 0
        else:
            commission_rate = billing.get('high_rate', 1500) if base > billing.get('threshold', 20000) else billing.get('low_rate', 2000)
        for purchase in purchases:
            purchase['rate'] = commission_rate


def _upgrade(payload):
    if isinstance(payload,dict) and payload.get('format')==FORMAT and payload.get('version') in (3,4,5):
        payload=copy.deepcopy(payload)
        tables=payload.get('tables')
        if isinstance(tables,dict):
            if payload.get('version')==3:
                tables['purchase_accounts']=[]
                tables['purchase_account_assignments']=[]
            if payload.get('version') in (3,4):
                for account in tables.get('purchase_accounts',[]):
                    account['active']=1
                tables['receipt_account_assignments']=[]
            _upgrade_purchase_rates(tables)
            payload['version']=VERSION
    return payload


def validate(payload):
    payload=_upgrade(payload)
    if not isinstance(payload, dict) or payload.get('format') != FORMAT or payload.get('version') != VERSION:
        raise BusinessError('El archivo no es un respaldo JSON V6 compatible.')
    account = payload.get('account')
    if payload.get('currency') != 'USD' or not isinstance(account, dict):
        raise BusinessError('El respaldo no declara una cuenta USD válida.')
    limits = {'threshold': (0, 100000000), 'low_rate': (0, 10000),
              'high_rate': (0, 10000), 'default_tax4': (0, 1000000)}
    if not isinstance(account.get('name'), str) or not 1 <= len(account['name'].strip()) <= 300:
        raise BusinessError('El respaldo contiene un nombre de cuenta inválido.')
    if any(not isinstance(account.get(key), int) or not low <= account[key] <= high
           for key, (low, high) in limits.items()):
        raise BusinessError('El respaldo contiene una configuración fuera de rango.')
    tables = payload.get('tables')
    if not isinstance(tables, dict) or set(tables) != set(TABLES):
        raise BusinessError('El respaldo no contiene todas las secciones requeridas.')
    if sum(len(rows) for rows in tables.values() if isinstance(rows, list)) > 100_000:
        raise BusinessError('El respaldo supera el máximo de 100 000 registros.')
    ids = {}
    for table in TABLES:
        table_rows = tables[table]
        if not isinstance(table_rows, list):
            raise BusinessError(f'La sección {table} no es una lista válida.')
        allowed = _columns(table) - {'owner_id'}
        seen = set()
        for row in table_rows:
            if not isinstance(row, dict) or set(row) != allowed:
                raise BusinessError(f'La sección {table} contiene campos no válidos.')
            if not isinstance(row['id'], int) or row['id'] <= 0 or row['id'] in seen:
                raise BusinessError(f'La sección {table} contiene identificadores duplicados o inválidos.')
            seen.add(row['id'])
            if table == 'purchase_photos':
                blob = _decode(row.get('original'))
                if not isinstance(blob, bytes) or hashlib.sha256(blob).hexdigest() != row.get('sha256') or len(blob) != row.get('size'):
                    raise BusinessError('Una foto del respaldo no coincide con su huella o tamaño.')
            for field in ('currency', 'source_currency', 'target_currency', 'cost_currency'):
                if field in row and row[field] != 'USD':
                    raise BusinessError('El respaldo contiene una moneda distinta de USD.')
            for field in ('usd_fx', 'fx', 'cost_fx'):
                if field in row and row[field] is not None and row[field] != 1000000:
                    raise BusinessError('El respaldo contiene un tipo de cambio incompatible con USD.')
        ids[table] = seen
    for table, fields in FOREIGN_KEYS.items():
        for row in tables[table]:
            for field, target in fields.items():
                value = row.get(field)
                if value is not None and value not in ids[target]:
                    raise BusinessError(f'El respaldo contiene una relación rota en {table}.{field}.')
    return payload


def clear_account(owner, delete_user=False):
    db = get_db()
    for table in DELETE_ORDER:
        db.execute(f'DELETE FROM {table} WHERE owner_id=?', (owner,))
    if delete_user:
        db.execute('DELETE FROM users WHERE id=?', (owner,))


def restore_account(owner, payload):
    payload = validate(payload)
    db = get_db()
    clear_account(owner)
    account = payload['account']
    db.execute(
        '''UPDATE users SET name=?,threshold=?,low_rate=?,high_rate=?,default_tax4=? WHERE id=?''',
        (str(account.get('name') or 'Shopper')[:300], int(account.get('threshold', 20000)),
         int(account.get('low_rate', 2000)), int(account.get('high_rate', 1500)),
         int(account.get('default_tax4', 0)), owner),
    )
    maps = {table: {} for table in TABLES}
    for table in INSERT_ORDER:
        allowed = _columns(table) - {'id', 'owner_id'}
        for source in payload['tables'][table]:
            values = {key: _decode(value) for key, value in source.items() if key in allowed}
            for field, target in FOREIGN_KEYS.get(table, {}).items():
                if values.get(field) is not None:
                    values[field] = maps[target][values[field]]
            if table == 'deliveries' and values.get('reversed_by') is not None:
                values['reversed_by'] = owner
            if table == 'audit':
                entity = values.get('entity')
                if entity == 'profile':
                    values['entity_id'] = owner
                elif entity in AUDIT_ENTITY_TABLE and values.get('entity_id') in maps[AUDIT_ENTITY_TABLE[entity]]:
                    values['entity_id'] = maps[AUDIT_ENTITY_TABLE[entity]][values['entity_id']]
            columns = ['owner_id', *values.keys()]
            params = [owner, *values.values()]
            placeholders = ','.join('?' for _ in params)
            new_id = db.execute(
                f'INSERT INTO {table}({",".join(columns)}) VALUES ({placeholders})', params
            ).lastrowid
            maps[table][source['id']] = new_id
    if not db.execute('SELECT id FROM purchase_accounts WHERE owner_id=?',(owner,)).fetchone():
        db.execute("INSERT INTO purchase_accounts(owner_id,name,kind,last4) VALUES (?,'Efectivo','cash','')",(owner,))
    db.execute('''INSERT INTO receipt_account_assignments(receipt_id,owner_id,account_id)
      SELECT r.id,r.owner_id,pa.id FROM receipts r
      JOIN accounts a ON a.id=r.account_id AND a.owner_id=r.owner_id
      JOIN purchase_accounts pa ON pa.owner_id=r.owner_id
       AND a.name=CASE WHEN pa.kind='card' AND pa.last4<>'' THEN pa.name||' · termina en '||pa.last4 ELSE pa.name END
      WHERE r.owner_id=? AND NOT EXISTS (
        SELECT 1 FROM receipt_account_assignments linked WHERE linked.receipt_id=r.id AND linked.owner_id=r.owner_id)
       AND (SELECT COUNT(*) FROM purchase_accounts match WHERE match.owner_id=r.owner_id
        AND a.name=CASE WHEN match.kind='card' AND match.last4<>'' THEN match.name||' · termina en '||match.last4 ELSE match.name END)=1''',(owner,))
    if db.execute('PRAGMA foreign_key_check').fetchall():
        raise BusinessError('La restauración produjo relaciones inválidas; no se guardó ningún cambio.')


def load_json(upload):
    if not upload or not upload.filename:
        raise BusinessError('Selecciona un archivo JSON de respaldo.')
    raw = upload.read(48 * 1024 * 1024 + 1)
    if len(raw) > 48 * 1024 * 1024:
        raise BusinessError('El respaldo supera 48 MB.')
    try:
        return json.loads(raw.decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise BusinessError('El archivo no contiene JSON UTF-8 válido.') from None
