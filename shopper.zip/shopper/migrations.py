"""Migración aditiva V1→V2. Nunca elimina movimientos ni recalcula el pasado."""
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

SQL = '''
ALTER TABLE users ADD COLUMN threshold INTEGER NOT NULL DEFAULT 20000 CHECK(threshold>=0);
ALTER TABLE users ADD COLUMN low_rate INTEGER NOT NULL DEFAULT 2000 CHECK(low_rate BETWEEN 0 AND 10000);
ALTER TABLE users ADD COLUMN high_rate INTEGER NOT NULL DEFAULT 1500 CHECK(high_rate BETWEEN 0 AND 10000);
ALTER TABLE users ADD COLUMN default_tax INTEGER NOT NULL DEFAULT 0 CHECK(default_tax BETWEEN 0 AND 10000);
CREATE TABLE billings (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, journey_id INTEGER NOT NULL, client_id INTEGER NOT NULL,
 currency TEXT NOT NULL CHECK(currency IN ('USD','NIO','EUR')), usd_fx INTEGER NOT NULL DEFAULT 1000000 CHECK(usd_fx>0),
 threshold INTEGER NOT NULL DEFAULT 20000 CHECK(threshold>=0), low_rate INTEGER NOT NULL DEFAULT 2000 CHECK(low_rate BETWEEN 0 AND 10000),
 high_rate INTEGER NOT NULL DEFAULT 1500 CHECK(high_rate BETWEEN 0 AND 10000),
 mode TEXT NOT NULL DEFAULT 'auto' CHECK(mode IN ('auto','rate','amount','legacy')),
 custom_rate INTEGER NOT NULL DEFAULT 0 CHECK(custom_rate BETWEEN 0 AND 10000), custom_amount INTEGER NOT NULL DEFAULT 0 CHECK(custom_amount>=0),
 weight INTEGER CHECK(weight>=0), per_lb INTEGER NOT NULL DEFAULT 0 CHECK(per_lb>=0),
 UNIQUE(id,owner_id), UNIQUE(id,owner_id,client_id,currency), UNIQUE(owner_id,journey_id,client_id,currency),
 FOREIGN KEY(journey_id,owner_id) REFERENCES journeys(id,owner_id), FOREIGN KEY(client_id,owner_id) REFERENCES clients(id,owner_id)
);
ALTER TABLE purchases ADD COLUMN billing_id INTEGER REFERENCES billings(id);
ALTER TABLE purchases ADD COLUMN tax_rate INTEGER NOT NULL DEFAULT 0 CHECK(tax_rate BETWEEN 0 AND 10000);
ALTER TABLE purchases ADD COLUMN usd_fx INTEGER CHECK(usd_fx>0);
ALTER TABLE purchases ADD COLUMN voided_at TEXT;
ALTER TABLE purchases ADD COLUMN void_reason TEXT NOT NULL DEFAULT '';
ALTER TABLE purchases ADD COLUMN revision INTEGER NOT NULL DEFAULT 1;
ALTER TABLE items ADD COLUMN archived INTEGER NOT NULL DEFAULT 0 CHECK(archived IN (0,1));
CREATE UNIQUE INDEX item_purchase_owner ON items(id,purchase_id,owner_id);
ALTER TABLE receipts ADD COLUMN voided_at TEXT;
ALTER TABLE receipts ADD COLUMN void_reason TEXT NOT NULL DEFAULT '';
CREATE UNIQUE INDEX receipt_owner_key ON receipts(id,owner_id);
ALTER TABLE deliveries ADD COLUMN reversed_at TEXT;
ALTER TABLE deliveries ADD COLUMN reverse_reason TEXT NOT NULL DEFAULT '';
ALTER TABLE deliveries ADD COLUMN reversed_by INTEGER REFERENCES users(id);
CREATE TABLE cash_applications (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, client_id INTEGER NOT NULL,
 receipt_id INTEGER NOT NULL, billing_id INTEGER NOT NULL,
 source_currency TEXT NOT NULL, target_currency TEXT NOT NULL,
 source_amount INTEGER NOT NULL CHECK(source_amount>0), amount INTEGER NOT NULL CHECK(amount>0),
 fx INTEGER NOT NULL CHECK(fx>0), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(receipt_id,owner_id,client_id,source_currency) REFERENCES receipts(id,owner_id,client_id,currency),
 FOREIGN KEY(billing_id,owner_id,client_id,target_currency) REFERENCES billings(id,owner_id,client_id,currency)
);
CREATE TABLE boxes (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, journey_id INTEGER NOT NULL,
 agency TEXT NOT NULL, tracking TEXT NOT NULL, currency TEXT NOT NULL CHECK(currency IN ('USD','NIO','EUR')),
 cost INTEGER NOT NULL CHECK(cost>=0), usd_fx INTEGER CHECK(usd_fx>0), legacy INTEGER NOT NULL DEFAULT 0,
 voided_at TEXT, void_reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(journey_id,owner_id) REFERENCES journeys(id,owner_id), UNIQUE(id,owner_id)
);
CREATE TABLE local_shipments (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, billing_id INTEGER NOT NULL,
 destination TEXT NOT NULL, agency TEXT NOT NULL, tracking TEXT NOT NULL DEFAULT '',
 cost INTEGER NOT NULL CHECK(cost>=0), charge INTEGER NOT NULL CHECK(charge>=0),
 cost_currency TEXT NOT NULL CHECK(cost_currency IN ('USD','NIO','EUR')), cost_original INTEGER NOT NULL CHECK(cost_original>=0), cost_fx INTEGER NOT NULL CHECK(cost_fx>0),
 status TEXT NOT NULL DEFAULT 'preparado' CHECK(status IN ('preparado','entregado','anulado')),
 reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(billing_id,owner_id) REFERENCES billings(id,owner_id), UNIQUE(id,owner_id)
);
CREATE TABLE local_items (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, shipment_id INTEGER NOT NULL, item_id INTEGER NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity>0), delivery_id INTEGER REFERENCES deliveries(id),
 FOREIGN KEY(shipment_id,owner_id) REFERENCES local_shipments(id,owner_id), FOREIGN KEY(item_id,owner_id) REFERENCES items(id,owner_id)
);
CREATE TABLE product_photos (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, purchase_id INTEGER NOT NULL, item_id INTEGER NOT NULL,
 original_name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, sha256 TEXT NOT NULL, original BLOB NOT NULL,
 removed_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(item_id,purchase_id,owner_id) REFERENCES items(id,purchase_id,owner_id)
);
CREATE TABLE invoice_documents (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, purchase_id INTEGER NOT NULL,
 original_name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, sha256 TEXT NOT NULL, original BLOB NOT NULL,
 extraction_status TEXT NOT NULL DEFAULT 'manual', extracted_json TEXT, removed_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(purchase_id,owner_id) REFERENCES purchases(id,owner_id)
);
CREATE INDEX billing_owner ON billings(owner_id,journey_id,client_id);
CREATE INDEX cash_bill ON cash_applications(owner_id,billing_id);
CREATE INDEX cash_receipt ON cash_applications(owner_id,receipt_id);
DROP TRIGGER delivery_limit;
CREATE TRIGGER delivery_limit BEFORE INSERT ON deliveries BEGIN
 SELECT CASE WHEN NEW.quantity+COALESCE((SELECT SUM(quantity) FROM deliveries WHERE item_id=NEW.item_id AND reversed_at IS NULL),0)
 > (SELECT quantity FROM items WHERE id=NEW.item_id) THEN RAISE(ABORT,'Entrega excesiva') END;
END;
CREATE TRIGGER cash_limit BEFORE INSERT ON cash_applications BEGIN
 SELECT CASE WHEN NEW.source_amount+COALESCE((SELECT SUM(source_amount) FROM cash_applications WHERE receipt_id=NEW.receipt_id),0)
 > (SELECT amount FROM receipts WHERE id=NEW.receipt_id) THEN RAISE(ABORT,'Crédito insuficiente') END;
 SELECT CASE WHEN (SELECT voided_at FROM receipts WHERE id=NEW.receipt_id) IS NOT NULL THEN RAISE(ABORT,'Recibo anulado') END;
END;
CREATE TRIGGER purchase_billing_owner BEFORE INSERT ON purchases WHEN NEW.billing_id IS NOT NULL BEGIN
 SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM billings b WHERE b.id=NEW.billing_id AND b.owner_id=NEW.owner_id AND b.client_id=NEW.client_id AND b.journey_id=NEW.journey_id)
 THEN RAISE(ABORT,'Cobro incompatible') END;
END;
CREATE TRIGGER purchase_billing_update BEFORE UPDATE OF billing_id,owner_id,client_id,journey_id ON purchases BEGIN
 SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM billings b WHERE b.id=NEW.billing_id AND b.owner_id=NEW.owner_id AND b.client_id=NEW.client_id AND b.journey_id=NEW.journey_id)
 THEN RAISE(ABORT,'Cobro incompatible') END;
END;
'''


def migrate_v2(db, database_path, backup=True):
    if db.execute('PRAGMA user_version').fetchone()[0] != 1:
        raise RuntimeError('La migración requiere esquema V1.')
    if backup:
        source = Path(database_path)
        folder = source.parent / 'backups'
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        target = sqlite3.connect(str(folder / f'{source.stem}-v1-{stamp}.sqlite'))
        try:
            db.backup(target)
        finally:
            target.close()
    try:
        db.executescript('BEGIN IMMEDIATE;\n'+SQL)
        db.execute("INSERT INTO billings(owner_id,journey_id,client_id,currency,mode) SELECT DISTINCT owner_id,journey_id,client_id,currency,'legacy' FROM purchases")
        db.execute('''UPDATE purchases SET billing_id=(SELECT b.id FROM billings b WHERE b.owner_id=purchases.owner_id AND b.journey_id=purchases.journey_id AND b.client_id=purchases.client_id AND b.currency=purchases.currency), usd_fx=CASE WHEN currency='USD' THEN 1000000 ELSE NULL END''')
        db.execute('''INSERT INTO cash_applications(owner_id,client_id,receipt_id,billing_id,source_currency,target_currency,source_amount,amount,fx,created_at)
            SELECT a.owner_id,a.client_id,a.receipt_id,p.billing_id,a.currency,a.currency,a.amount,a.amount,1000000,a.created_at FROM allocations a JOIN purchases p ON p.id=a.purchase_id''')
        db.execute('''INSERT INTO boxes(owner_id,journey_id,agency,tracking,currency,cost,usd_fx,legacy)
            SELECT owner_id,journey_id,'Histórico V1','Sin tracking en V1',currency,SUM(shipping_cost),CASE WHEN currency='USD' THEN 1000000 ELSE NULL END,1
            FROM purchases GROUP BY owner_id,journey_id,currency HAVING SUM(shipping_cost)>0''')
        if db.execute('PRAGMA foreign_key_check').fetchall():
            raise RuntimeError('Migración cancelada: claves foráneas inconsistentes.')
        db.execute('PRAGMA user_version=2')
        db.commit()
    except Exception:
        db.rollback()
        raise


V3_SQL = '''
ALTER TABLE users ADD COLUMN default_tax4 INTEGER NOT NULL DEFAULT 0 CHECK(default_tax4 BETWEEN 0 AND 1000000);
ALTER TABLE purchases ADD COLUMN tax_rate4 INTEGER NOT NULL DEFAULT 0 CHECK(tax_rate4 BETWEEN 0 AND 1000000);
CREATE TABLE purchase_photos (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, purchase_id INTEGER NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN ('product','invoice')),
 original_name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL,
 sha256 TEXT NOT NULL, original BLOB NOT NULL,
 extraction_status TEXT NOT NULL DEFAULT 'manual', removed_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(id,owner_id),
 FOREIGN KEY(purchase_id,owner_id) REFERENCES purchases(id,owner_id)
);
CREATE INDEX purchase_photo_owner ON purchase_photos(owner_id,purchase_id);
'''


def migrate_v3(db, database_path, backup=True):
    """V2→V3. La versión solicitada permite reiniciar los datos existentes."""
    if db.execute('PRAGMA user_version').fetchone()[0] != 2:
        raise RuntimeError('La migración requiere esquema V2.')
    if backup:
        source = Path(database_path)
        folder = source.parent / 'backups'
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        target = sqlite3.connect(str(folder / f'{source.stem}-v2-{stamp}.sqlite'))
        try:
            db.backup(target)
        finally:
            target.close()
    try:
        db.executescript('BEGIN IMMEDIATE;\n' + V3_SQL)
        # El usuario autorizó reiniciar los datos para adoptar USD y adjuntos unificados.
        for table in ('local_items','local_shipments','product_photos','invoice_documents',
                      'cash_applications','allocations','deliveries','items','receipts',
                      'purchases','boxes','billings','accounts','products','stores',
                      'audit','clients','journeys','users'):
            db.execute(f'DELETE FROM {table}')
        if db.execute('PRAGMA foreign_key_check').fetchall():
            raise RuntimeError('Migración cancelada: claves foráneas inconsistentes.')
        db.execute('PRAGMA user_version=3')
        db.commit()
    except Exception:
        db.rollback()
        raise


V4_SQL = '''
CREATE TABLE purchase_accounts (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, name TEXT NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN ('card','cash','transfer','other')),
 last4 TEXT NOT NULL DEFAULT '' CHECK(length(last4)<=4),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(id,owner_id), UNIQUE(owner_id,name,kind,last4),
 FOREIGN KEY(owner_id) REFERENCES users(id)
);
CREATE TABLE purchase_account_assignments (
 id INTEGER PRIMARY KEY, purchase_id INTEGER NOT NULL, owner_id INTEGER NOT NULL, account_id INTEGER NOT NULL,
 UNIQUE(id,owner_id), UNIQUE(purchase_id), UNIQUE(purchase_id,owner_id),
 FOREIGN KEY(purchase_id,owner_id) REFERENCES purchases(id,owner_id),
 FOREIGN KEY(account_id,owner_id) REFERENCES purchase_accounts(id,owner_id)
);
CREATE INDEX purchase_account_owner ON purchase_accounts(owner_id,name);
CREATE INDEX purchase_account_assignment_owner ON purchase_account_assignments(owner_id,account_id);
INSERT INTO purchase_accounts(owner_id,name,kind,last4)
 SELECT id,'Efectivo','cash','' FROM users;
'''


def migrate_v4(db, database_path, backup=True):
    """V3→V4. Añade cuentas de compra sin atribuir datos históricos."""
    if db.execute('PRAGMA user_version').fetchone()[0] != 3:
        raise RuntimeError('La migración requiere esquema V3.')
    if backup:
        source = Path(database_path)
        folder = source.parent / 'backups'
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        target = sqlite3.connect(str(folder / f'{source.stem}-v3-{stamp}.sqlite'))
        try:
            db.backup(target)
        finally:
            target.close()
    try:
        db.executescript('BEGIN IMMEDIATE;\n' + V4_SQL)
        if db.execute('PRAGMA foreign_key_check').fetchall():
            raise RuntimeError('Migración cancelada: claves foráneas inconsistentes.')
        db.execute('PRAGMA user_version=4')
        db.commit()
    except Exception:
        db.rollback()
        raise


V5_SQL = '''
ALTER TABLE purchase_accounts ADD COLUMN active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1));
CREATE TABLE receipt_account_assignments (
 id INTEGER PRIMARY KEY, receipt_id INTEGER NOT NULL, owner_id INTEGER NOT NULL, account_id INTEGER NOT NULL,
 UNIQUE(id,owner_id), UNIQUE(receipt_id), UNIQUE(receipt_id,owner_id),
 FOREIGN KEY(receipt_id,owner_id) REFERENCES receipts(id,owner_id),
 FOREIGN KEY(account_id,owner_id) REFERENCES purchase_accounts(id,owner_id)
);
CREATE INDEX receipt_account_assignment_owner ON receipt_account_assignments(owner_id,account_id);
INSERT INTO receipt_account_assignments(receipt_id,owner_id,account_id)
 SELECT r.id,r.owner_id,pa.id
 FROM receipts r
 JOIN accounts a ON a.id=r.account_id AND a.owner_id=r.owner_id
 JOIN purchase_accounts pa ON pa.owner_id=r.owner_id
  AND a.name=CASE WHEN pa.kind='card' AND pa.last4<>'' THEN pa.name||' · termina en '||pa.last4 ELSE pa.name END
 WHERE (SELECT COUNT(*) FROM purchase_accounts match
        WHERE match.owner_id=r.owner_id
          AND a.name=CASE WHEN match.kind='card' AND match.last4<>'' THEN match.name||' · termina en '||match.last4 ELSE match.name END)=1;
'''


def migrate_v5(db, database_path, backup=True):
    """V4→V5. Añade administración de cuentas y relaciones estables con recibos."""
    if db.execute('PRAGMA user_version').fetchone()[0] != 4:
        raise RuntimeError('La migración requiere esquema V4.')
    if backup:
        source = Path(database_path)
        folder = source.parent / 'backups'
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        target = sqlite3.connect(str(folder / f'{source.stem}-v4-{stamp}.sqlite'))
        try:
            db.backup(target)
        finally:
            target.close()
    try:
        db.executescript('BEGIN IMMEDIATE;\n' + V5_SQL)
        if db.execute('PRAGMA foreign_key_check').fetchall():
            raise RuntimeError('Migración cancelada: claves foráneas inconsistentes.')
        db.execute('PRAGMA user_version=5')
        db.commit()
    except Exception:
        db.rollback()
        raise


def migrate_v6(db, database_path, backup=True):
    """V5→V6. Traslada la tasa del cobro consolidado a cada compra."""
    if db.execute('PRAGMA user_version').fetchone()[0] != 5:
        raise RuntimeError('La migración requiere esquema V5.')
    if backup:
        source = Path(database_path)
        folder = source.parent / 'backups'
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        target = sqlite3.connect(str(folder / f'{source.stem}-v5-{stamp}.sqlite'))
        try:
            db.backup(target)
        finally:
            target.close()
    try:
        db.execute('BEGIN IMMEDIATE')
        for billing in db.execute('SELECT * FROM billings').fetchall():
            purchases = db.execute('SELECT * FROM purchases WHERE billing_id=? AND owner_id=?',
                                   (billing['id'], billing['owner_id'])).fetchall()
            active_bases = []
            for purchase in purchases:
                if purchase['voided_at']:
                    continue
                subtotal = db.execute(
                    'SELECT COALESCE(SUM(quantity*price),0) FROM items WHERE purchase_id=? AND owner_id=? AND archived=0',
                    (purchase['id'], purchase['owner_id']),
                ).fetchone()[0]
                tax = (subtotal * purchase['tax_rate4'] + 500000) // 1000000
                active_bases.append(subtotal + tax)
            base = sum(active_bases)
            if billing['mode'] == 'legacy':
                continue
            if billing['mode'] == 'rate':
                commission_rate = billing['custom_rate']
            elif billing['mode'] == 'amount':
                commission_rate = min(10000, (billing['custom_amount'] * 10000 + base // 2) // base) if base else 0
            else:
                commission_rate = billing['high_rate'] if base > billing['threshold'] else billing['low_rate']
            db.execute('UPDATE purchases SET rate=? WHERE billing_id=? AND owner_id=?',
                       (commission_rate, billing['id'], billing['owner_id']))
        if db.execute('PRAGMA foreign_key_check').fetchall():
            raise RuntimeError('Migración cancelada: claves foráneas inconsistentes.')
        db.execute('PRAGMA user_version=6')
        db.commit()
    except Exception:
        db.rollback()
        raise
