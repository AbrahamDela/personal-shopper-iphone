"""Reglas monetarias: ninguna operación de negocio utiliza float."""
import re
from datetime import date
from decimal import Decimal


class BusinessError(ValueError):
    pass


def money(value, maximum=100000000):
    raw = str(value).strip().replace(',', '.')
    if not re.fullmatch(r'\d{1,9}(?:\.\d{1,2})?', raw):
        raise BusinessError('Introduce un importe no negativo con hasta dos decimales.')
    result = int(Decimal(raw) * 100)
    if result > maximum:
        raise BusinessError('El importe supera el máximo permitido.')
    return result


def rate(value):
    return money(value, 10000)


def tax_rate(value):
    """Porcentaje con cuatro decimales: 7.1250 % se guarda como 71250."""
    return scaled(value, 4, 1000000, 'Tax')


def integer(value, maximum=10000):
    if not re.fullmatch(r'[0-9]+', str(value)) or not 1 <= int(value) <= maximum:
        raise BusinessError(f'Introduce una cantidad entera entre 1 y {maximum}.')
    return int(value)


def valid_date(value):
    try:
        return date.fromisoformat(value).isoformat()
    except (ValueError, TypeError):
        raise BusinessError('Introduce una fecha válida.') from None


def text(value, label='Nombre', required=True, limit=300):
    value = str(value or '').strip()
    if (required and not value) or len(value) > limit:
        raise BusinessError(f'{label}: obligatorio y hasta {limit} caracteres.' if required else f'{label}: hasta {limit} caracteres.')
    return value


def currency(value):
    if value != 'USD':
        raise BusinessError('La aplicación solo admite dólares estadounidenses (USD).')
    return 'USD'


def totals(items, rate_bps, shipping=0, shipping_cost=0):
    subtotal = sum(i['quantity'] * i['price'] for i in items)
    commission = (subtotal * rate_bps + 5000) // 10000
    return dict(subtotal=subtotal, commission=commission,
                total=subtotal + commission + shipping,
                profit=commission + shipping - shipping_cost)


def scaled(value, digits, maximum, label):
    raw = str(value or '').strip().replace(',', '.')
    if not re.fullmatch(r'\d{1,9}(?:\.\d{1,'+str(digits)+r'})?', raw):
        raise BusinessError(f'{label}: usa un número positivo con hasta {digits} decimales.')
    result = int(Decimal(raw) * (10 ** digits))
    if result > maximum:
        raise BusinessError(f'{label}: supera el máximo permitido.')
    return result


def exchange(value):
    result = scaled(value, 6, 100000000000, 'Tipo de cambio')
    if not result:
        raise BusinessError('El tipo de cambio debe ser mayor que cero.')
    return result


def weight(value):
    return scaled(value, 3, 100000000, 'Peso en libras')


def convert(cents, fx):
    if not fx:
        raise BusinessError('Falta registrar la conversión explícita de moneda.')
    return (cents * fx + 500000) // 1000000


def percent(cents, bps):
    return (cents * bps + 5000) // 10000


def tax_percent(cents, rate4):
    return (cents * rate4 + 500000) // 1000000


def commission_rate(subtotal_usd, threshold, low_rate, high_rate):
    return high_rate if subtotal_usd > threshold else low_rate
