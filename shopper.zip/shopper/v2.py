"""Operaciones V2. Todos los importes y conversiones son enteros escalados."""
import json
from .db import get_db
from .domain import BusinessError, currency, integer, money, rate, tax_rate, text, valid_date, weight, convert, percent, tax_percent, commission_rate
from .services import rows, owned, audit, catalog


def profile(owner):
    return dict(get_db().execute('SELECT * FROM users WHERE id=?',(owner,)).fetchone())


def purchase_account_label(account):
    account_id=account.get('payment_account_id') if 'payment_account_id' in account else account.get('id')
    if not account_id:
        return 'Sin registrar'
    name=account.get('payment_account_name') or account.get('name')
    kind=account.get('payment_account_kind') or account.get('kind')
    last4=account.get('payment_account_last4') or account.get('last4')
    return f'{name} · termina en {last4}' if kind=='card' and last4 else name


def save_purchase_account(owner,form,account_id=None):
    db=get_db(); current=owned('purchase_accounts',account_id,owner) if account_id else None
    name=text(form.get('name'),'Nombre de la cuenta')
    kind=form.get('kind','')
    if kind not in ('card','cash','transfer','other'):
        raise BusinessError('Selecciona un tipo de cuenta válido.')
    last4=(form.get('last4') or '').strip()
    if kind=='card':
        if not 1<=len(last4)<=4 or not last4.isdigit():
            raise BusinessError('Escribe de 1 a 4 dígitos finales de la tarjeta.')
    elif last4:
        raise BusinessError('Los últimos dígitos se usan únicamente para tarjetas.')
    duplicate=rows('SELECT id FROM purchase_accounts WHERE owner_id=? AND name=? AND kind=? AND last4=? AND id!=?',
                   (owner,name,kind,last4,account_id or 0))
    if duplicate: raise BusinessError('Esa cuenta ya está registrada.')
    if current:
        db.execute('UPDATE purchase_accounts SET name=?,kind=?,last4=? WHERE id=? AND owner_id=?',(name,kind,last4,account_id,owner))
        audit(owner,'purchase_account',account_id,'actualizada',{'before':current,'after':{'name':name,'kind':kind,'last4':last4}})
        return account_id
    account_id=db.execute('INSERT INTO purchase_accounts(owner_id,name,kind,last4) VALUES (?,?,?,?)',(owner,name,kind,last4)).lastrowid
    audit(owner,'purchase_account',account_id,'creada',{'kind':kind,'last4':last4})
    return account_id


def change_purchase_account_status(owner,account_id):
    account=owned('purchase_accounts',account_id,owner)
    active=not bool(account['active'])
    if not active and len(rows('SELECT id FROM purchase_accounts WHERE owner_id=? AND active=1',(owner,)))<=1:
        raise BusinessError('Debes conservar al menos una cuenta activa.')
    get_db().execute('UPDATE purchase_accounts SET active=? WHERE id=? AND owner_id=?',(int(active),account_id,owner))
    audit(owner,'purchase_account',account_id,'reactivada' if active else 'desactivada',{})
    return active


def purchase_account_activity(owner,account_id):
    account=owned('purchase_accounts',account_id,owner)
    account['display_name']=purchase_account_label(account)
    account['purchases']=[p for p in purchases(owner) if p['payment_account_id']==account_id]
    receipt_ids={row['receipt_id'] for row in rows('SELECT receipt_id FROM receipt_account_assignments WHERE owner_id=? AND account_id=?',(owner,account_id))}
    account['receipts']=[receipt for receipt in receipts(owner) if receipt['id'] in receipt_ids]
    account['purchase_total']=sum(p['total'] for p in account['purchases'] if not p['voided_at'])
    account['receipt_total']=sum(r['amount'] for r in account['receipts'] if not r['voided_at'])
    return account


def items(owner, purchase_id=None):
    result=rows('''SELECT i.*,
      COALESCE((SELECT SUM(d.quantity) FROM deliveries d WHERE d.item_id=i.id AND d.owner_id=i.owner_id AND d.reversed_at IS NULL),0) delivered,
      COALESCE((SELECT SUM(li.quantity) FROM local_items li JOIN local_shipments s ON s.id=li.shipment_id WHERE li.item_id=i.id AND s.owner_id=i.owner_id AND s.status='preparado'),0) reserved
      FROM items i WHERE i.owner_id=? ORDER BY i.id''',(owner,))
    return [i for i in result if purchase_id is None or i['purchase_id']==purchase_id]


def purchases(owner):
    ps=rows('''SELECT p.*,c.name client_name,s.name store_name,j.name journey_name,
      paa.account_id payment_account_id,pa.name payment_account_name,
      pa.kind payment_account_kind,pa.last4 payment_account_last4 FROM purchases p
      JOIN clients c ON c.id=p.client_id JOIN stores s ON s.id=p.store_id JOIN journeys j ON j.id=p.journey_id
      LEFT JOIN purchase_account_assignments paa ON paa.purchase_id=p.id AND paa.owner_id=p.owner_id
      LEFT JOIN purchase_accounts pa ON pa.id=paa.account_id AND pa.owner_id=p.owner_id
      WHERE p.owner_id=? ORDER BY p.date DESC,p.id DESC''',(owner,))
    all_items=items(owner)
    for p in ps:
        p['items']=[i for i in all_items if i['purchase_id']==p['id'] and not i['archived']]
        p['subtotal']=sum(i['quantity']*i['price'] for i in p['items'])
        p['tax']=tax_percent(p['subtotal'],p['tax_rate4'])
        p['total']=p['subtotal']+p['tax']
        p['commission']=percent(p['total'],p['rate'])
        p['charged_total']=p['total']+p['commission']
        p['payment_account_label']=purchase_account_label(p)
        p['pending']=0 if p['voided_at'] else sum(i['quantity']-i['delivered'] for i in p['items'])
    return ps


def purchase(owner,pid):
    owned('purchases',pid,owner)
    return next(p for p in purchases(owner) if p['id']==int(pid))


def receipts(owner):
    rs=rows('''SELECT r.*,c.name client_name,a.name account_name,
      r.amount-COALESCE((SELECT SUM(x.source_amount) FROM cash_applications x WHERE x.receipt_id=r.id AND x.owner_id=r.owner_id),0) available
      FROM receipts r JOIN clients c ON c.id=r.client_id JOIN accounts a ON a.id=r.account_id WHERE r.owner_id=? ORDER BY r.id DESC''',(owner,))
    for r in rs:
        if r['voided_at']: r['available']=0
        r['applications']=rows('SELECT * FROM cash_applications WHERE receipt_id=? AND owner_id=?',(r['id'],owner))
    return rs


def billing(owner,bid):
    b=owned('billings',bid,owner)
    b['client_name']=owned('clients',b['client_id'],owner)['name']
    b['purchases']=[p for p in purchases(owner) if p['billing_id']==b['id']]
    active=[p for p in b['purchases'] if not p['voided_at']]
    b['active_count']=len(active)
    b['pending_units']=sum(p['pending'] for p in active)
    b['fx_missing']=any(not p['usd_fx'] for p in active)
    b['subtotal_usd']=None if b['fx_missing'] else sum(convert(p['subtotal'],p['usd_fx']) for p in active)
    if b['mode']=='legacy':
        b['subtotal']=sum(p['subtotal'] for p in active)
        b['tax']=sum(p['tax'] for p in active)
        b['shipping']=sum(p['shipping'] for p in active)
    else:
        if b['fx_missing']:
            raise BusinessError('Este cobro requiere completar los cambios de moneda de sus compras.')
        b['subtotal']=convert(b['subtotal_usd'],b['usd_fx'])
        tax_usd=sum(convert(p['tax'],p['usd_fx']) for p in active)
        b['tax']=convert(tax_usd,b['usd_fx'])
        b['shipping']=((b['weight'] or 0)*b['per_lb']+500)//1000
        if not active: b['shipping']=0
    b['commission']=sum(p['commission'] for p in active)
    b['applied_rate']=None
    locals_=rows("SELECT * FROM local_shipments WHERE owner_id=? AND billing_id=? AND status!='anulado'",(owner,b['id']))
    b['local_charge']=sum(s['charge'] for s in locals_)
    b['local_cost']=sum(s['cost'] for s in locals_)
    b['total']=b['subtotal']+b['tax']+b['commission']+b['shipping']+b['local_charge']
    b['paid']=sum(r['amount'] for r in rows('''SELECT a.amount FROM cash_applications a JOIN receipts r ON r.id=a.receipt_id
       WHERE a.owner_id=? AND a.billing_id=? AND r.voided_at IS NULL''',(owner,b['id'])))
    b['balance']=b['total']-b['paid']
    b['provisional']=b['weight'] is None or b['mode']=='legacy'
    return b


def billings(owner,journey_id=None,client_id=None):
    bs=rows('SELECT id,journey_id,client_id FROM billings WHERE owner_id=? ORDER BY id DESC',(owner,))
    return [billing(owner,b['id']) for b in bs if (journey_id is None or b['journey_id']==journey_id) and (client_id is None or b['client_id']==client_id)]


def balances(owner,client_id=None):
    result={}
    for b in billings(owner,client_id=client_id):
        key=(b['client_id'],b['currency'])
        r=result.setdefault(key,dict(id=b['client_id'],name=b['client_name'],currency=b['currency'],charges=0,paid=0,balance=0))
        r['charges']+=b['total']; r['paid']+=b['paid']; r['balance']+=b['balance']
    for receipt in receipts(owner):
        if receipt['voided_at'] or (client_id is not None and receipt['client_id']!=client_id): continue
        key=(receipt['client_id'],receipt['currency'])
        if receipt['available']:
            r=result.setdefault(key,dict(id=receipt['client_id'],name=receipt['client_name'],currency=receipt['currency'],charges=0,paid=0,balance=0))
            r['paid']+=receipt['available']; r['balance']-=receipt['available']
    return list(result.values())


def open_journey(owner,jid):
    j=owned('journeys',jid,owner)
    if j['status']!='abierta': raise BusinessError('Reabre la jornada antes de cambiar compras, cargos o cajas.')
    return j


def ensure_bill(owner,jid,cid):
    bs=rows('SELECT * FROM billings WHERE owner_id=? AND journey_id=? AND client_id=?',(owner,jid,cid))
    if bs:
        if len(bs)>1 or bs[0]['mode']=='legacy':
            raise BusinessError('Prepara primero el cobro histórico con las reglas V2. Si hay varias monedas históricas, conserva esa jornada y crea una nueva para compras V2.')
        return bs[0]['id']
    u=profile(owner)
    return get_db().execute('INSERT INTO billings(owner_id,journey_id,client_id,currency,threshold,low_rate,high_rate) VALUES (?,?,?,\'USD\',?,?,?)',(owner,jid,cid,u['threshold'],u['low_rate'],u['high_rate'])).lastrowid


def save_purchase(owner,form,pid=None):
    old=purchase(owner,pid) if pid else None
    if old:
        if old['voided_at']: raise BusinessError('Una compra anulada solo se puede consultar.')
        if integer(form.get('revision'),2147483647)!=old['revision']: raise BusinessError('La compra cambió en otra sesión. Recarga antes de editar.')
        jid,cid,bid=old['journey_id'],old['client_id'],old['billing_id']
    else:
        jid=owned('journeys',form.get('journey_id'),owner)['id']
        cid=owned('clients',form.get('client_id'),owner)['id']
        bid=None
    open_journey(owner,jid)
    payment_account=owned('purchase_accounts',form.get('payment_account_id'),owner)
    if not payment_account['active'] and (not old or old['payment_account_id']!=payment_account['id']):
        raise BusinessError('Selecciona una cuenta activa.')
    if form.get('confirmed')!='yes': raise BusinessError('Revisa y confirma los datos antes de guardar la factura de compra.')
    names,qs,prices=(form.getlist(k) for k in ('product','quantity','price'))
    ids=form.getlist('item_id') or ['']*len(names)
    if not 1<=len(names)<=100 or not len(names)==len(qs)==len(prices)==len(ids): raise BusinessError('Incluye de 1 a 100 líneas completas.')
    lines=[dict(id=ids[n],name=text(name,'Producto'),quantity=integer(qs[n]),price=money(prices[n])) for n,name in enumerate(names)]
    cur=currency(form.get('currency','USD'))
    fx=1000000
    tax=tax_rate(form.get('tax_rate'))
    subtotal=sum(line['quantity']*line['price'] for line in lines)
    tax_amount=tax_percent(subtotal,tax)
    commission_value=form.get('commission_rate')
    if commission_value in (None,''):
        user_profile=profile(owner)
        purchase_rate=commission_rate(subtotal+tax_amount,user_profile['threshold'],user_profile['low_rate'],user_profile['high_rate'])
    else:
        purchase_rate=rate(commission_value)
    store=catalog('stores',owner,text(form.get('store'),'Tienda'))
    fields=(store,valid_date(form.get('date')),cur,tax,fx,purchase_rate,text(form.get('reference'),'Referencia',False),text(form.get('order_note'),'Notas',False,1000))
    db=get_db()
    if old:
        reason=text(form.get('reason'),'Motivo de edición')
        db.execute('UPDATE purchases SET store_id=?,date=?,currency=?,tax_rate4=?,usd_fx=?,rate=?,reference=?,order_note=?,revision=revision+1 WHERE id=? AND owner_id=?',(*fields,pid,owner))
    else:
        bid=ensure_bill(owner,jid,cid)
        pid=db.execute('''INSERT INTO purchases(owner_id,journey_id,client_id,billing_id,store_id,date,currency,tax_rate4,usd_fx,rate,reference,order_note,shipping,shipping_cost)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,0,0)''',(owner,jid,cid,bid,*fields)).lastrowid
        reason='Alta de compra'
    db.execute('''INSERT INTO purchase_account_assignments(purchase_id,owner_id,account_id) VALUES (?,?,?)
       ON CONFLICT(purchase_id) DO UPDATE SET account_id=excluded.account_id
       WHERE purchase_account_assignments.owner_id=excluded.owner_id''',(pid,owner,payment_account['id']))
    existing={i['id']:i for i in items(owner,pid)}
    seen=set(); line_ids=[]
    for line in lines:
        product=catalog('products',owner,line['name'])
        if line['id']:
            iid=integer(line['id'],2147483647)
            if iid not in existing or iid in seen: raise BusinessError('Línea de compra no válida.')
            if line['quantity']<existing[iid]['delivered']+existing[iid]['reserved']: raise BusinessError('Revierte entregas o cancela envíos antes de reducir esta cantidad.')
            db.execute('UPDATE items SET product_id=?,description=?,quantity=?,price=?,archived=0 WHERE id=? AND owner_id=?',(product,line['name'],line['quantity'],line['price'],iid,owner))
            seen.add(iid)
        else:
            iid=db.execute('INSERT INTO items(owner_id,purchase_id,product_id,description,quantity,price) VALUES (?,?,?,?,?,?)',(owner,pid,product,line['name'],line['quantity'],line['price'])).lastrowid
        line_ids.append(iid)
    for iid,item in existing.items():
        if iid not in seen:
            if item['delivered'] or item['reserved']: raise BusinessError('Una línea con entregas o envíos preparados no se puede retirar.')
            db.execute('UPDATE items SET archived=1 WHERE id=? AND owner_id=?',(iid,owner))
    db.execute('UPDATE billings SET weight=NULL WHERE id=? AND owner_id=?',(bid,owner))
    audit(owner,'purchase',pid,'editada' if old else 'creada',{'reason':reason,'before':old,'after':purchase(owner,pid)})
    return pid,line_ids


def void_purchase(owner,pid,reason):
    p=purchase(owner,pid); open_journey(owner,p['journey_id'])
    if p['voided_at']: raise BusinessError('La compra ya está anulada.')
    if any(i['delivered'] or i['reserved'] for i in p['items']): raise BusinessError('Revierte las entregas y cancela los envíos locales de esta compra antes de anularla.')
    reason=text(reason,'Motivo de anulación')
    get_db().execute('UPDATE purchases SET voided_at=CURRENT_TIMESTAMP,void_reason=?,revision=revision+1 WHERE id=? AND owner_id=?',(reason,pid,owner))
    get_db().execute('UPDATE billings SET weight=NULL WHERE id=? AND owner_id=?',(p['billing_id'],owner))
    audit(owner,'purchase',pid,'anulada',{'reason':reason,'before':p})


def prepare_bill(owner,bid,form):
    b=billing(owner,bid); open_journey(owner,b['journey_id'])
    if b['fx_missing']: raise BusinessError('Edita las compras sin conversión a USD antes de preparar este cobro.')
    if b['mode']=='legacy' and len(rows('SELECT id FROM billings WHERE owner_id=? AND journey_id=? AND client_id=?',(owner,b['journey_id'],b['client_id'])))>1:
        raise BusinessError('Esta jornada tiene varios cobros históricos por moneda. Se conservan sin convertir automáticamente; usa una nueva jornada para las reglas V2.')
    cur=currency(form.get('currency','USD'))
    fx=1000000
    if (cur!=b['currency'] or fx!=b['usd_fx']) and (rows('SELECT id FROM cash_applications WHERE owner_id=? AND billing_id=?',(owner,bid)) or rows('SELECT id FROM local_shipments WHERE owner_id=? AND billing_id=?',(owner,bid))):
        raise BusinessError('Con pagos o envíos locales registrados no se puede cambiar la moneda ni su conversión. Conserva el historial.')
    values=(cur,fx,weight(form.get('weight')),money(form.get('per_lb')),bid,owner)
    get_db().execute("UPDATE billings SET currency=?,usd_fx=?,mode='auto',custom_rate=0,custom_amount=0,weight=?,per_lb=? WHERE id=? AND owner_id=?",values)
    audit(owner,'billing',bid,'preparado',{'before':{k:b[k] for k in ('mode','currency','weight','per_lb','total')},'after':{k:billing(owner,bid)[k] for k in ('mode','currency','weight','per_lb','total')}})


def apply_credit(owner,rid,bid,amount,fx_value):
    r=owned('receipts',rid,owner); b=billing(owner,bid)
    if r['voided_at'] or r['client_id']!=b['client_id']: raise BusinessError('Recibo anulado o de otro cliente.')
    if r['currency']!='USD' or b['currency']!='USD': raise BusinessError('La aplicación solo admite USD.')
    fx=1000000
    amount=money(amount)
    used=sum(a['source_amount'] for a in rows('SELECT source_amount FROM cash_applications WHERE receipt_id=? AND owner_id=?',(rid,owner)))
    if amount<=0 or amount>r['amount']-used: raise BusinessError('El importe supera el crédito disponible.')
    applied=convert(amount,fx)
    if not applied: raise BusinessError('La conversión redondea a cero. Revisa el importe y el cambio.')
    aid=get_db().execute('''INSERT INTO cash_applications(owner_id,client_id,receipt_id,billing_id,source_currency,target_currency,source_amount,amount,fx)
      VALUES (?,?,?,?,?,?,?,?,?)''',(owner,b['client_id'],rid,bid,r['currency'],b['currency'],amount,applied,fx)).lastrowid
    audit(owner,'application',aid,'aplicada',{'receipt':rid,'billing':bid,'source_amount':amount,'amount':applied,'fx':fx})


def create_receipt(owner,form):
    cid=owned('clients',form.get('client_id'),owner)['id']
    cur=currency(form.get('currency','USD')); amount=money(form.get('amount'))
    if not amount: raise BusinessError('El abono debe ser mayor que cero.')
    purchase_account=owned('purchase_accounts',form.get('purchase_account_id'),owner)
    if not purchase_account['active']: raise BusinessError('Selecciona una cuenta activa.')
    name=purchase_account_label(purchase_account); db=get_db()
    db.execute('INSERT OR IGNORE INTO accounts(owner_id,name,currency) VALUES (?,?,?)',(owner,name,cur))
    account=db.execute('SELECT id FROM accounts WHERE owner_id=? AND name=? AND currency=?',(owner,name,cur)).fetchone()['id']
    rid=db.execute('INSERT INTO receipts(owner_id,client_id,account_id,date,currency,amount,reference) VALUES (?,?,?,?,?,?,?)',(owner,cid,account,valid_date(form.get('date')),cur,amount,text(form.get('reference'),'Referencia',False))).lastrowid
    db.execute('INSERT INTO receipt_account_assignments(receipt_id,owner_id,account_id) VALUES (?,?,?)',(rid,owner,purchase_account['id']))
    if form.get('billing_id'): apply_credit(owner,rid,integer(form['billing_id'],2147483647),form['amount'],form.get('fx'))
    audit(owner,'receipt',rid,'creado',{'amount':amount,'currency':cur,'purchase_account_id':purchase_account['id']})
    return rid,cid


def void_receipt(owner,rid,reason):
    r=owned('receipts',rid,owner)
    if r['voided_at']: raise BusinessError('El recibo ya está anulado.')
    reason=text(reason,'Motivo de anulación')
    get_db().execute('UPDATE receipts SET voided_at=CURRENT_TIMESTAMP,void_reason=? WHERE id=? AND owner_id=?',(reason,rid,owner))
    audit(owner,'receipt',rid,'anulado',{'reason':reason,'amount':r['amount']})
    return r['client_id']


def deliver(owner,iid,form,shipment=False):
    i=next((i for i in items(owner) if i['id']==iid),None)
    if not i or i['archived']: raise BusinessError('Producto no disponible.')
    p=owned('purchases',i['purchase_id'],owner)
    if p['voided_at']: raise BusinessError('La compra está anulada.')
    if form.get('confirmed')!='yes': raise BusinessError('Confirma producto, cantidad y nota antes de entregar.')
    qty=integer(form.get('quantity'))
    if qty>i['quantity']-i['delivered']-(0 if shipment else i['reserved']): raise BusinessError('No hay suficientes unidades libres. Revisa los envíos locales preparados.')
    did=get_db().execute('INSERT INTO deliveries(owner_id,item_id,quantity,date,note) VALUES (?,?,?,?,?)',(owner,iid,qty,valid_date(form.get('date')),text(form.get('note'),'Nota',False))).lastrowid
    audit(owner,'delivery',did,'creada',{'product':i['description'],'quantity':qty})
    return did,p['id']


def reverse_delivery(owner,did,reason,shipment=False):
    d=owned('deliveries',did,owner)
    if d['reversed_at']: raise BusinessError('La entrega ya está revertida.')
    if not shipment and rows('SELECT id FROM local_items WHERE owner_id=? AND delivery_id=?',(owner,did)):
        raise BusinessError('Esta entrega pertenece a un envío local. Revierte el envío completo desde su detalle.')
    reason=text(reason,'Motivo de reversión')
    get_db().execute('UPDATE deliveries SET reversed_at=CURRENT_TIMESTAMP,reverse_reason=?,reversed_by=? WHERE id=? AND owner_id=?',(reason,owner,did,owner))
    audit(owner,'delivery',did,'revertida',{'reason':reason,'quantity':d['quantity']})
    return owned('items',d['item_id'],owner)['purchase_id']


def create_box(owner,jid,form):
    open_journey(owner,jid)
    cur=currency(form.get('currency','USD'))
    fx=1000000
    box=get_db().execute('INSERT INTO boxes(owner_id,journey_id,agency,tracking,currency,cost,usd_fx) VALUES (?,?,?,?,?,?,?)',(owner,jid,text(form.get('agency'),'Agencia'),text(form.get('tracking'),'Tracking'),cur,money(form.get('cost')),fx)).lastrowid
    audit(owner,'box',box,'registrada',{'journey':jid})


def create_local(owner,bid,form):
    b=billing(owner,bid)
    quantities=form.getlist('quantity'); ids=form.getlist('item_id')
    if len(ids)!=len(quantities): raise BusinessError('Detalle de envío incompleto.')
    selected=[]; seen=set()
    for iid,q in zip(ids,quantities):
        if q in ('','0'): continue
        iid=integer(iid,2147483647); qty=integer(q)
        if iid in seen: raise BusinessError('Producto repetido en el envío.')
        seen.add(iid)
        i=next((i for i in items(owner) if i['id']==iid),None)
        p=owned('purchases',i['purchase_id'],owner) if i else None
        if not i or i['archived'] or p['voided_at'] or p['billing_id']!=bid or qty>i['quantity']-i['delivered']-i['reserved']:
            raise BusinessError('El envío contiene productos incompatibles o cantidades no disponibles.')
        selected.append((iid,qty))
    if not selected: raise BusinessError('Selecciona al menos un producto para el envío.')
    cost_cur=currency(form.get('cost_currency','USD'))
    cost_original=money(form.get('cost'))
    cost_fx=1000000
    sid=get_db().execute('INSERT INTO local_shipments(owner_id,billing_id,destination,agency,tracking,cost,charge,cost_currency,cost_original,cost_fx) VALUES (?,?,?,?,?,?,?,?,?,?)',(owner,bid,text(form.get('destination'),'Destino'),text(form.get('agency'),'Agencia'),text(form.get('tracking'),'Tracking',False),convert(cost_original,cost_fx),money(form.get('charge')),cost_cur,cost_original,cost_fx)).lastrowid
    for iid,qty in selected:
        get_db().execute('INSERT INTO local_items(owner_id,shipment_id,item_id,quantity) VALUES (?,?,?,?)',(owner,sid,iid,qty))
    audit(owner,'local',sid,'preparado',{'items':selected,'billing':bid})
    return sid


def change_local(owner,sid,form):
    s=owned('local_shipments',sid,owner)
    action=form.get('action'); reason=text(form.get('reason'),'Nota / motivo')
    lines=rows('SELECT * FROM local_items WHERE shipment_id=? AND owner_id=?',(sid,owner))
    if action=='deliver' and s['status']=='preparado':
        if form.get('confirmed')!='yes': raise BusinessError('Revisa el contenido y confirma la entrega del envío local.')
        for i in lines:
            did,_=deliver(owner,i['item_id'],dict(quantity=str(i['quantity']),date=form.get('date'),note=reason,confirmed='yes'),shipment=True)
            get_db().execute('UPDATE local_items SET delivery_id=? WHERE id=? AND owner_id=?',(did,i['id'],owner))
        status='entregado'
    elif action=='reverse' and s['status']=='entregado':
        for i in lines: reverse_delivery(owner,i['delivery_id'],reason,shipment=True)
        # Vuelve a preparado: conserva cargos/costos y reserva las unidades.
        status='preparado'
    elif action=='cancel' and s['status']=='preparado':
        status='anulado'
    else: raise BusinessError('Acción incompatible con el estado del envío.')
    get_db().execute('UPDATE local_shipments SET status=?,reason=? WHERE id=? AND owner_id=?',(status,reason,sid,owner))
    audit(owner,'local',sid,action,{'reason':reason,'from':s['status'],'to':status})
    return s['billing_id']


def journey_result(owner,jid):
    j=owned('journeys',jid,owner); bs=billings(owner,journey_id=jid)
    boxes=rows('SELECT * FROM boxes WHERE owner_id=? AND journey_id=? ORDER BY id',(owner,jid))
    active=[x for x in boxes if not x['voided_at']]
    missing=any(not x['usd_fx'] for x in active) or any(b['mode']=='legacy' and b['currency']!='USD' for b in bs)
    result=dict(journey=j,billings=bs,boxes=boxes,missing_fx=missing,provisional=j['status']!='cerrada' or any(b['provisional'] and b['active_count'] for b in bs) or not active,
                box_totals=[],cash=[],billed=[])
    account_groups={}
    for billing in bs:
        for purchase_ in billing['purchases']:
            if purchase_['voided_at']: continue
            account_id=purchase_['payment_account_id']
            key=f'account:{account_id}' if account_id else 'purchase:unassigned'
            group=account_groups.setdefault(key,dict(
                account_id=account_id,label=purchase_['payment_account_label'],kind=purchase_.get('payment_account_kind'),
                active=None,purchase_count=0,purchases_total=0,receipt_ids=set(),received_total=0))
            group['purchase_count']+=1
            group['purchases_total']+=purchase_['total']
    received_by_account=rows('''SELECT ca.receipt_id,ca.amount,raa.account_id,pa.name,pa.kind,pa.last4,pa.active,a.name legacy_name
      FROM cash_applications ca
      JOIN receipts r ON r.id=ca.receipt_id AND r.owner_id=ca.owner_id
      JOIN billings b ON b.id=ca.billing_id AND b.owner_id=ca.owner_id
      JOIN accounts a ON a.id=r.account_id AND a.owner_id=r.owner_id
      LEFT JOIN receipt_account_assignments raa ON raa.receipt_id=r.id AND raa.owner_id=r.owner_id
      LEFT JOIN purchase_accounts pa ON pa.id=raa.account_id AND pa.owner_id=r.owner_id
      WHERE ca.owner_id=? AND b.journey_id=? AND r.voided_at IS NULL''',(owner,jid))
    for movement in received_by_account:
        account_id=movement['account_id']
        key=f'account:{account_id}' if account_id else f"receipt:{movement['legacy_name']}"
        label=purchase_account_label(dict(id=account_id,name=movement['name'],kind=movement['kind'],last4=movement['last4'])) if account_id else movement['legacy_name']
        group=account_groups.setdefault(key,dict(
            account_id=account_id,label=label,kind=movement['kind'],active=movement['active'],
            purchase_count=0,purchases_total=0,receipt_ids=set(),received_total=0))
        if group['active'] is None: group['active']=movement['active']
        group['receipt_ids'].add(movement['receipt_id'])
        group['received_total']+=movement['amount']
    for group in account_groups.values():
        if group['account_id'] and group['active'] is None:
            account=owned('purchase_accounts',group['account_id'],owner)
            group['active']=account['active']
        group['receipt_count']=len(group.pop('receipt_ids'))
    result['account_summary']=sorted(account_groups.values(),key=lambda group:(group['label'].casefold(),group['account_id'] or 0))
    for cur in ('USD',):
        result['box_totals'].append(dict(currency=cur,total=sum(x['cost'] for x in active if x['currency']==cur)))
        group=[b for b in bs if b['currency']==cur]
        if group: result['billed'].append(dict(currency=cur,total=sum(b['total'] for b in group),paid=sum(b['paid'] for b in group),balance=sum(b['balance'] for b in group)))
        received=rows('''SELECT a.source_amount FROM cash_applications a JOIN receipts r ON r.id=a.receipt_id JOIN billings b ON b.id=a.billing_id
          WHERE a.owner_id=? AND b.journey_id=? AND a.source_currency=? AND r.voided_at IS NULL''',(owner,jid,cur))
        if received: result['cash'].append(dict(currency=cur,total=sum(r['source_amount'] for r in received)))
    if not missing:
        # La inversa usa racionales enteros; no crea un cambio de mercado implícito.
        back=lambda amount,b: (amount*1000000+b['usd_fx']//2)//b['usd_fx']
        result['commissions']=sum(back(b['commission'],b) for b in bs)
        result['shipping']=sum(back(b['shipping'],b) for b in bs)
        result['box_cost']=sum(convert(x['cost'],x['usd_fx']) for x in active)
        result['local_charge']=sum(back(b['local_charge'],b) for b in bs)
        result['local_cost']=sum(back(b['local_cost'],b) for b in bs)
        result['profit']=result['commissions']+result['shipping']-result['box_cost']
        result['profit_with_local']=result['profit']+result['local_charge']-result['local_cost']
    return result


def close_journey(owner,jid):
    r=journey_result(owner,jid)
    if r['journey']['status']=='cerrada':
        state='abierta'
    else:
        if not any(not x['voided_at'] for x in r['boxes']): raise BusinessError('Registra al menos una caja con agencia, tracking y costo antes del cierre.')
        if not r['billings'] or any(b['active_count'] and (b['weight'] is None or b['mode']=='legacy') for b in r['billings']): raise BusinessError('Prepara el peso y el cobro V2 de cada cliente antes del cierre.')
        if r['missing_fx']: raise BusinessError('Completa las conversiones antes del cierre.')
        state='cerrada'
    get_db().execute('UPDATE journeys SET status=? WHERE id=? AND owner_id=?',(state,jid,owner))
    audit(owner,'journey',jid,'estado',{'to':state})
