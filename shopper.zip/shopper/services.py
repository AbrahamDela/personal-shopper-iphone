"""Consultas con propietario explícito y escrituras transaccionales."""
import json
from .db import get_db
from .domain import BusinessError


def rows(sql, params=()):
    return [dict(r) for r in get_db().execute(sql, params).fetchall()]


def owned(table, entity_id, owner):
    # table siempre es una constante del servidor, nunca un campo del navegador.
    result = rows(f'SELECT * FROM {table} WHERE id=? AND owner_id=?', (entity_id, owner))
    if not result:
        raise BusinessError('Registro no disponible para esta cuenta.')
    return result[0]


def audit(owner, entity, entity_id, action, detail):
    get_db().execute('INSERT INTO audit(owner_id,entity,entity_id,action,detail) VALUES (?,?,?,?,?)',
                     (owner, entity, entity_id, action, json.dumps(detail, ensure_ascii=False)))


def catalog(table, owner, name):
    db = get_db()
    db.execute(f'INSERT OR IGNORE INTO {table}(owner_id,name) VALUES (?,?)', (owner, name))
    return db.execute(f'SELECT id FROM {table} WHERE owner_id=? AND name=?', (owner, name)).fetchone()['id']
