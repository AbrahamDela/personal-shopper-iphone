import io
import json
import re
from urllib.parse import urlencode
from flask import g,request,render_template,redirect,url_for,flash,send_file,abort,session,jsonify,current_app
from . import v2 as svc
from . import files
from . import backup
from . import gemini
from . import reports
from .db import get_db
from .domain import BusinessError,integer,money,rate,tax_rate,text,valid_date


def register_views(app):
    def render(name,**kwargs): return render_template('v2/'+name+'.html',**kwargs)
    def owner(): return g.user['id']
    def success(message,endpoint,**params):
        flash(message,'success'); return redirect(url_for(endpoint,**params))
    def search_query(): return request.args.get('q','').strip()[:100]
    def matches(query,*values): return not query or query.casefold() in ' '.join(str(value or '') for value in values).casefold()

    @app.template_filter('decimal')
    def decimal(value,places=2):
        if value is None: return ''
        sign='-' if value<0 else ''; value=abs(value); scale=10**places
        return f'{sign}{value//scale}.{value%scale:0{places}d}'

    @app.get('/')
    def dashboard():
        return render('dashboard',balances=svc.balances(owner()),purchases=svc.purchases(owner()),billings=svc.billings(owner()),journeys=svc.rows('SELECT * FROM journeys WHERE owner_id=? ORDER BY id DESC',(owner(),)))

    @app.route('/clientes',methods=['GET','POST'])
    def clients():
        if request.method=='POST':
            cid=get_db().execute('INSERT INTO clients(owner_id,name,phone,address,rate) VALUES (?,?,?,?,0)',(owner(),text(request.form.get('name')),text(request.form.get('phone'),'Teléfono',False),text(request.form.get('address'),'Dirección',False))).lastrowid
            svc.audit(owner(),'client',cid,'creado',{})
            return success('Cliente registrado.','client_detail',client_id=cid)
        query=search_query()
        all_clients=svc.rows('SELECT * FROM clients WHERE owner_id=? ORDER BY name',(owner(),))
        clients=[client for client in all_clients if matches(query,f"cliente #{client['id']}",client['name'],client['phone'],client['address'])]
        return render('clients',clients=clients,total=len(all_clients),query=query)

    @app.get('/clientes/<int:client_id>')
    def client_detail(client_id):
        return render('client',client=svc.owned('clients',client_id,owner()),billings=svc.billings(owner(),client_id=client_id),balances=svc.balances(owner(),client_id),receipts=[r for r in svc.receipts(owner()) if r['client_id']==client_id])

    @app.route('/jornadas',methods=['GET','POST'])
    def journeys():
        if request.method=='POST':
            jid=get_db().execute('INSERT INTO journeys(owner_id,name,date) VALUES (?,?,?)',(owner(),text(request.form.get('name')),valid_date(request.form.get('date')))).lastrowid
            svc.audit(owner(),'journey',jid,'creada',{})
            return success('Jornada creada.','journey_detail',journey_id=jid)
        query=search_query()
        all_journeys=svc.rows('SELECT * FROM journeys WHERE owner_id=? ORDER BY id DESC',(owner(),))
        journeys=[journey for journey in all_journeys if matches(
            query,f"jornada #{journey['id']}",journey['name'],journey['date'],journey['status'])]
        return render_template('journeys.html',journeys=journeys,total=len(all_journeys),query=query)

    @app.route('/jornadas/<int:journey_id>',methods=['GET','POST'])
    def journey_detail(journey_id):
        if request.method=='POST':
            svc.close_journey(owner(),journey_id)
            return success('Estado de la jornada actualizado.','journey_detail',journey_id=journey_id)
        return render('journey',r=svc.journey_result(owner(),journey_id))

    @app.get('/jornadas/<int:journey_id>/consolidado.xlsx')
    def journey_consolidated_report(journey_id):
        result=svc.journey_result(owner(),journey_id)
        return send_file(
            reports.build_journey_consolidated_report(result,g.user['name']),
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=reports.consolidated_filename(result['journey']),
            max_age=0,
        )

    @app.post('/jornadas/<int:journey_id>/cajas')
    def box_create(journey_id):
        svc.create_box(owner(),journey_id,request.form)
        return success('Caja registrada por separado.','journey_detail',journey_id=journey_id)

    @app.post('/cajas/<int:box_id>/anular')
    def box_void(box_id):
        b=svc.owned('boxes',box_id,owner()); svc.open_journey(owner(),b['journey_id'])
        if b['voided_at']: raise BusinessError('La caja ya está anulada.')
        reason=text(request.form.get('reason'),'Motivo')
        get_db().execute('UPDATE boxes SET voided_at=CURRENT_TIMESTAMP,void_reason=? WHERE id=? AND owner_id=?',(reason,box_id,owner()))
        svc.audit(owner(),'box',box_id,'anulada',{'reason':reason})
        return success('Registro de caja anulado.','journey_detail',journey_id=b['journey_id'])

    def purchase_form(pid=None):
        p=svc.purchase(owner(),pid) if pid else None
        if request.method=='POST':
            pid,line_ids=svc.save_purchase(owner(),request.form,pid)
            files.attach(owner(),pid,request.files,request.form)
            return success('Compra y fotos guardadas. Revisa el cobro consolidado del cliente.','purchase_detail',purchase_id=pid)
        if p and p['payment_account_id']:
            purchase_accounts=svc.rows('SELECT * FROM purchase_accounts WHERE owner_id=? AND (active=1 OR id=?) ORDER BY active DESC,name,last4,id',(owner(),p['payment_account_id']))
        else:
            purchase_accounts=svc.rows('SELECT * FROM purchase_accounts WHERE owner_id=? AND active=1 ORDER BY name,last4,id',(owner(),))
        for account in purchase_accounts: account['display_name']=svc.purchase_account_label(account)
        return render('purchase_form',p=p,profile=svc.profile(owner()),clients=svc.rows('SELECT * FROM clients WHERE owner_id=? ORDER BY name',(owner(),)),
                      journeys=svc.rows("SELECT * FROM journeys WHERE owner_id=? AND status='abierta' ORDER BY id DESC",(owner(),)),products=svc.rows('SELECT * FROM products WHERE owner_id=? ORDER BY name',(owner(),)),
                      stores=svc.rows('SELECT * FROM stores WHERE owner_id=? ORDER BY name',(owner(),)),files=files.list_files(owner(),pid) if pid else None,
                      purchase_accounts=purchase_accounts,gemini_enabled=gemini.is_configured(current_app.config))

    @app.get('/compras')
    def purchase_list():
        query=request.args.get('q','').strip()[:100]
        status=request.args.get('estado','todas')
        if status not in ('todas','vigentes','pendientes','entregadas','anuladas'):
            status='todas'
        all_purchases=svc.purchases(owner())
        filtered=all_purchases
        if query:
            needle=query.casefold()
            filtered=[p for p in filtered if needle in ' '.join((
                str(p['id']),p['client_name'],p['store_name'],p['journey_name'],
                p['payment_account_label'],p['date'],p.get('reference') or '',
            )).casefold()]
        if status=='vigentes': filtered=[p for p in filtered if not p['voided_at']]
        elif status=='pendientes': filtered=[p for p in filtered if not p['voided_at'] and p['pending']]
        elif status=='entregadas': filtered=[p for p in filtered if not p['voided_at'] and not p['pending']]
        elif status=='anuladas': filtered=[p for p in filtered if p['voided_at']]
        return render('purchases',purchases=filtered,total=len(all_purchases),query=query,status=status)

    @app.route('/compras/nueva',methods=['GET','POST'])
    def purchase_new(): return purchase_form()

    @app.post('/compras/clientes')
    def purchase_client_create():
        try:
            name=text(request.form.get('name'))
            phone=text(request.form.get('phone'),'Teléfono',False)
            address=text(request.form.get('address'),'Dirección',False)
            cid=get_db().execute(
                'INSERT INTO clients(owner_id,name,phone,address,rate) VALUES (?,?,?,?,0)',
                (owner(),name,phone,address),
            ).lastrowid
            svc.audit(owner(),'client',cid,'creado',{'origin':'registro de compra'})
            return jsonify(id=cid,name=name)
        except BusinessError as error:
            return jsonify(error=str(error)),400

    @app.post('/compras/cuentas')
    def purchase_account_create():
        try:
            account_id=svc.save_purchase_account(owner(),request.form)
            account=svc.owned('purchase_accounts',account_id,owner())
            return jsonify(id=account_id,name=svc.purchase_account_label(account))
        except BusinessError as error:
            return jsonify(error=str(error)),400

    @app.route('/cuentas',methods=['GET','POST'])
    def account_list():
        if request.method=='POST':
            account_id=svc.save_purchase_account(owner(),request.form)
            return success('Cuenta registrada.','account_detail',account_id=account_id)
        accounts=svc.rows('SELECT * FROM purchase_accounts WHERE owner_id=? ORDER BY active DESC,name,last4,id',(owner(),))
        for account in accounts:
            account['display_name']=svc.purchase_account_label(account)
            account['purchase_count']=svc.rows('SELECT COUNT(*) count FROM purchase_account_assignments WHERE owner_id=? AND account_id=?',(owner(),account['id']))[0]['count']
            account['receipt_count']=svc.rows('SELECT COUNT(*) count FROM receipt_account_assignments WHERE owner_id=? AND account_id=?',(owner(),account['id']))[0]['count']
        query=search_query(); total=len(accounts)
        kind_labels={'card':'tarjeta','cash':'efectivo','transfer':'transferencia','other':'otra'}
        accounts=[account for account in accounts if matches(
            query,f"cuenta #{account['id']}",account['display_name'],kind_labels.get(account['kind']),
            'activa' if account['active'] else 'desactivada')]
        return render('accounts',accounts=accounts,total=total,query=query)

    @app.route('/cuentas/<int:account_id>',methods=['GET','POST'])
    def account_detail(account_id):
        if request.method=='POST':
            svc.save_purchase_account(owner(),request.form,account_id)
            return success('Cuenta actualizada.','account_detail',account_id=account_id)
        return render('account',account=svc.purchase_account_activity(owner(),account_id))

    @app.post('/cuentas/<int:account_id>/estado')
    def account_status(account_id):
        active=svc.change_purchase_account_status(owner(),account_id)
        return success('Cuenta reactivada.' if active else 'Cuenta desactivada.','account_detail',account_id=account_id)

    @app.route('/compras/<int:purchase_id>/editar',methods=['GET','POST'])
    def purchase_edit(purchase_id): return purchase_form(purchase_id)

    @app.post('/compras/analizar-fotos')
    def analyze_purchase_photos():
        try:
            images=files.read_uploads(request.files,request.form)
            return jsonify(gemini.analyze(images,current_app.config))
        except BusinessError as error:
            return jsonify(error=str(error)),400

    @app.get('/compras/<int:purchase_id>')
    def purchase_detail(purchase_id):
        p=svc.purchase(owner(),purchase_id)
        return render('purchase',p=p,b=svc.billing(owner(),p['billing_id']),files=files.list_files(owner(),purchase_id),
              deliveries=svc.rows('SELECT d.*,i.description FROM deliveries d JOIN items i ON i.id=d.item_id WHERE d.owner_id=? AND i.purchase_id=? ORDER BY d.id DESC',(owner(),purchase_id)))

    @app.post('/compras/<int:purchase_id>/anular')
    def purchase_void(purchase_id):
        svc.void_purchase(owner(),purchase_id,request.form.get('reason'))
        return success('Compra anulada; los archivos y pagos permanecen en el historial.','purchase_detail',purchase_id=purchase_id)

    @app.route('/cobros/<int:billing_id>',methods=['GET','POST'])
    def billing_detail(billing_id):
        if request.method=='POST':
            svc.prepare_bill(owner(),billing_id,request.form)
            return success('Cobro actualizado una sola vez para este cliente y jornada.','billing_detail',billing_id=billing_id)
        b=svc.billing(owner(),billing_id)
        return render('billing',b=b,journey=svc.owned('journeys',b['journey_id'],owner()),
                      locals=svc.rows('SELECT * FROM local_shipments WHERE owner_id=? AND billing_id=? ORDER BY id DESC',(owner(),billing_id)),
                      applications=svc.rows('SELECT a.*,r.voided_at FROM cash_applications a JOIN receipts r ON r.id=a.receipt_id WHERE a.owner_id=? AND a.billing_id=? ORDER BY a.id',(owner(),billing_id)))

    @app.get('/cobros/<int:billing_id>/reporte.xlsx')
    def billing_report(billing_id):
        b=svc.billing(owner(),billing_id)
        journey=svc.owned('journeys',b['journey_id'],owner())
        return send_file(
            reports.build_client_report(b,journey),
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=reports.report_filename(b,journey),
            max_age=0,
        )

    @app.route('/recibos',methods=['GET','POST'])
    def receipt_list():
        if request.method=='POST':
            _,cid=svc.create_receipt(owner(),request.form)
            return success('Recibo guardado en USD.','client_detail',client_id=cid)
        purchase_accounts=svc.rows('SELECT * FROM purchase_accounts WHERE owner_id=? AND active=1 ORDER BY name,last4,id',(owner(),))
        for account in purchase_accounts: account['display_name']=svc.purchase_account_label(account)
        query=search_query(); all_receipts=svc.receipts(owner())
        receipts=[receipt for receipt in all_receipts if matches(
            query,f"recibo #{receipt['id']}",receipt['client_name'],receipt['account_name'],receipt['date'],
            receipt['reference'],f"{receipt['amount']//100}.{receipt['amount']%100:02d}",
            'anulado' if receipt['voided_at'] else 'activo')]
        return render('receipts',receipts=receipts,total=len(all_receipts),query=query,billings=svc.billings(owner()),clients=svc.rows('SELECT * FROM clients WHERE owner_id=? ORDER BY name',(owner(),)),purchase_accounts=purchase_accounts)

    @app.post('/recibos/<int:receipt_id>/anular')
    def receipt_void(receipt_id):
        cid=svc.void_receipt(owner(),receipt_id,request.form.get('reason'))
        return success('Recibo anulado; su efecto sobre el saldo fue revertido.','client_detail',client_id=cid)

    @app.post('/aplicaciones')
    def allocate():
        bid=integer(request.form.get('billing_id'),2147483647)
        svc.apply_credit(owner(),integer(request.form.get('receipt_id'),2147483647),bid,request.form.get('amount'),request.form.get('fx'))
        return success('Crédito aplicado.','billing_detail',billing_id=bid)

    @app.get('/entregas')
    def deliveries():
        query=search_query()
        pending=[p for p in svc.purchases(owner()) if p['pending']]
        purchases=pending
        if query:
            needle=query.casefold()
            purchases=[p for p in pending if needle in ' '.join((
                f"compra #{p['id']}",p['client_name'],p['store_name'],p['journey_name'],
                *(item['description'] for item in p['items'] if item['quantity']>item['delivered']),
            )).casefold()]
        return render_template('deliveries.html',purchases=purchases,total=len(pending),query=query)

    @app.post('/entregas/<int:item_id>')
    def deliver(item_id):
        _,pid=svc.deliver(owner(),item_id,request.form)
        return success('Entrega registrada.','purchase_detail',purchase_id=pid)

    @app.post('/entregas/<int:delivery_id>/revertir')
    def delivery_reverse(delivery_id):
        pid=svc.reverse_delivery(owner(),delivery_id,request.form.get('reason'))
        return success('Entrega revertida con motivo y responsable.','purchase_detail',purchase_id=pid)

    @app.route('/cobros/<int:billing_id>/envios',methods=['GET','POST'])
    def local_create(billing_id):
        b=svc.billing(owner(),billing_id)
        if request.method=='POST':
            sid=svc.create_local(owner(),billing_id,request.form)
            return success('Envío preparado. El costo de agencia no genera un cargo automático.','local_detail',shipment_id=sid)
        return render('local_form',b=b)

    @app.route('/envios/<int:shipment_id>',methods=['GET','POST'])
    def local_detail(shipment_id):
        s=svc.owned('local_shipments',shipment_id,owner())
        if request.method=='POST':
            svc.change_local(owner(),shipment_id,request.form)
            return success('Estado del envío actualizado.','local_detail',shipment_id=shipment_id)
        return render('local',s=s,b=svc.billing(owner(),s['billing_id']),lines=svc.rows('SELECT li.*,i.description FROM local_items li JOIN items i ON i.id=li.item_id WHERE li.owner_id=? AND li.shipment_id=?',(owner(),shipment_id)))

    @app.route('/perfil',methods=['GET','POST'])
    def profile():
        if request.method=='POST':
            old=svc.profile(owner())
            get_db().execute('UPDATE users SET threshold=?,low_rate=?,high_rate=?,default_tax4=? WHERE id=?',(money(request.form.get('threshold')),rate(request.form.get('low_rate')),rate(request.form.get('high_rate')),tax_rate(request.form.get('default_tax')),owner()))
            svc.audit(owner(),'profile',owner(),'configuración',{'before':{k:old[k] for k in ('threshold','low_rate','high_rate','default_tax4')},'after':{k:svc.profile(owner())[k] for k in ('threshold','low_rate','high_rate','default_tax4')}})
            return success('Configuración guardada. Las compras y cobros existentes conservan sus tasas.','profile')
        return render('profile',profile=svc.profile(owner()),events=svc.rows('SELECT * FROM audit WHERE owner_id=? ORDER BY id DESC LIMIT 100',(owner(),)))

    @app.get('/configuracion/respaldo')
    def backup_export():
        payload=json.dumps(backup.export_account(owner()),ensure_ascii=False,separators=(',',':')).encode('utf-8')
        return send_file(io.BytesIO(payload),mimetype='application/json',as_attachment=True,
                         download_name='respaldo-personal-shopper-v5.json',max_age=0)

    @app.post('/configuracion/restaurar')
    def backup_import():
        if request.form.get('confirmation')!='reemplazar_mis_datos':
            raise BusinessError('Escribe exactamente reemplazar_mis_datos para restaurar el respaldo.')
        backup.restore_account(owner(),backup.load_json(request.files.get('backup')))
        flash('Respaldo validado y restaurado. Los datos operativos anteriores fueron reemplazados.','success')
        return redirect(url_for('profile'))

    @app.post('/configuracion/eliminar-todo')
    def delete_account():
        if request.form.get('confirmation')!='borrar_todos_mis_datos':
            raise BusinessError('Escribe exactamente borrar_todos_mis_datos para eliminar la cuenta.')
        backup.clear_account(owner(),delete_user=True)
        session.clear()
        flash('La cuenta y todos sus datos, incluidas las fotos, fueron eliminados.','success')
        return redirect(url_for('login'))

    @app.get('/archivos/<kind>/<int:file_id>')
    def file_view(kind,file_id):
        if kind not in files.TABLES: abort(404)
        f=svc.owned(files.TABLES[kind],file_id,owner())
        return send_file(io.BytesIO(f['original']),mimetype=f['mime'],download_name=f['original_name'],as_attachment=request.args.get('download')=='1',max_age=0)

    @app.post('/archivos/<kind>/<int:file_id>/retirar')
    def file_remove(kind,file_id):
        if kind not in files.TABLES: abort(404)
        f=svc.owned(files.TABLES[kind],file_id,owner()); p=svc.owned('purchases',f['purchase_id'],owner())
        svc.open_journey(owner(),p['journey_id'])
        if p['voided_at']: raise BusinessError('Los archivos de compras anuladas se conservan para consulta.')
        pid=files.remove(owner(),kind,file_id,text(request.form.get('reason'),'Motivo'))
        return success('Archivo retirado de la vista activa; original conservado en el historial.','purchase_edit',purchase_id=pid)

    @app.route('/compartir/<kind>/<int:entity_id>',methods=['GET','POST'])
    def share(kind,entity_id):
        if kind=='purchase':
            p=svc.purchase(owner(),entity_id)
            if p['voided_at']: raise BusinessError('No se comparte una compra anulada.')
            client=svc.owned('clients',p['client_id'],owner())
            parts=[f"Compra #{p['id']} · {p['store_name']}"]
            parts.extend(f"{i['description']} · {i['quantity']} × {p['currency']} {i['price']/100:.2f}" for i in p['items'])
            parts.extend((f"Productos: USD {p['subtotal']/100:.2f}",f"Tax: USD {p['tax']/100:.2f}",
                          f"Comisión ({p['rate']/100:.2f}%): USD {p['commission']/100:.2f}",
                          f"Total con comisión: USD {p['charged_total']/100:.2f}"))
            message='\n'.join(parts)
        elif kind=='billing':
            b=svc.billing(owner(),entity_id); client=svc.owned('clients',b['client_id'],owner())
            if b['weight'] is None or b['mode']=='legacy' or svc.owned('journeys',b['journey_id'],owner())['status']!='cerrada':
                raise BusinessError('Prepara el peso y cierra la jornada antes de compartir su resumen.')
            parts=[f"Resumen para {client['name']}"]
            for p in b['purchases']:
                if not p['voided_at']:
                    parts.append(f"Compra #{p['id']} · {p['store_name']}")
                    parts.extend(f"{i['description']} · {i['quantity']} × {p['currency']} {i['price']/100:.2f}" for i in p['items'])
            parts.append(f"Peso: {b['weight']/1000:.3f} lb")
            for label,key in [('Productos','subtotal'),('Tax','tax'),('Envío internacional','shipping'),('Comisión','commission'),('Envío local cobrado','local_charge'),('Total a pagar','total'),('Abonos aplicados','paid'),('Saldo','balance')]:
                parts.append(f"{label}: {b['currency']} {b[key]/100:.2f}")
            message='\n'.join(parts)
        else: abort(404)
        phone=re.sub(r'\D','',client['phone'])
        if len(phone)==8: phone='505'+phone
        url='https://wa.me/'+(phone if 8<=len(phone)<=15 else '')+'?'+urlencode({'text':message})
        return render('share',message=message,phone=phone,url=url)
