"""Reportes Excel de cobros por cliente y jornada."""
from datetime import date
from io import BytesIO
import re
import unicodedata

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


NAVY = "17324D"
GREEN = "1E6B57"
LIGHT_GREEN = "EAF2EC"
LIGHT_BLUE = "EAF0F5"
WHITE = "FFFFFF"
GRAY = "667085"
THIN = Side(style="thin", color="D7DEE5")
MONEY_FORMAT = '$#,##0.00;[Red]-$#,##0.00'


def _dollars(cents):
    return cents / 100


def _merge_value(sheet, cell_range, value, *, fill=None, font=None, alignment=None):
    sheet.merge_cells(cell_range)
    cell = sheet[cell_range.split(":", 1)[0]]
    cell.value = value
    if fill:
        cell.fill = fill
    if font:
        cell.font = font
    if alignment:
        cell.alignment = alignment
    return cell


def _header(sheet, cell_range, value):
    return _merge_value(
        sheet,
        cell_range,
        value,
        fill=PatternFill("solid", fgColor=NAVY),
        font=Font(color=WHITE, bold=True),
        alignment=Alignment(horizontal="center", vertical="center"),
    )


def _label(sheet, cell, value):
    target = sheet[cell]
    target.value = value
    target.font = Font(size=9, bold=True, color=GRAY)


def _money(sheet, cell, cents, *, bold=False):
    target = sheet[cell]
    target.value = _dollars(cents)
    target.number_format = MONEY_FORMAT
    target.font = Font(bold=bold)
    return target


def _folio(billing, journey):
    return f"J{journey['id']:04d}-C{billing['client_id']:04d}-B{billing['id']:04d}"


def _safe_filename(value):
    cleaned = re.sub(r"[^A-Za-z0-9áéíóúÁÉÍÓÚñÑ_-]+", "-", value.strip())
    return cleaned.strip("-")[:80] or "cliente"


def _alphabetical_name(value):
    normalized = unicodedata.normalize("NFKD", value)
    return "".join(character for character in normalized if not unicodedata.combining(character)).casefold()


def report_filename(billing, journey):
    return f"reporte-{_safe_filename(journey['name'])}-{_safe_filename(billing['client_name'])}.xlsx"


def consolidated_filename(journey):
    return f"consolidado-{_safe_filename(journey['name'])}.xlsx"


def build_client_report(billing, journey, generated_on=None):
    """Crea un snapshot del cobro; los totales ya fueron calculados por el dominio."""
    generated_on = generated_on or date.today()
    active = [purchase for purchase in billing["purchases"] if not purchase["voided_at"]]
    workbook = Workbook()
    summary = workbook.active
    summary.title = "Resumen"
    details = workbook.create_sheet("Detalles")
    _build_summary(summary, billing, journey, active, generated_on)
    _build_details(details, billing, journey, active)
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output


def build_journey_consolidated_report(result, owner_name, generated_on=None):
    """Crea la cartera consolidada de clientes de una jornada."""
    generated_on = generated_on or date.today()
    billings = sorted(
        (billing for billing in result["billings"] if billing["active_count"]),
        key=lambda billing: (_alphabetical_name(billing["client_name"]), billing["id"]),
    )
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Consolidado"
    _build_consolidated(sheet, result["journey"], billings, owner_name, generated_on)
    accounts = workbook.create_sheet("Cuentas")
    _build_accounts(accounts, result["journey"], result.get("account_summary", []), owner_name, generated_on)
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output


def _build_accounts(sheet, journey, accounts, owner_name, generated_on):
    """Resume compras activas y abonos aplicados a la jornada por cuenta."""
    sheet.sheet_view.showGridLines = False
    sheet.freeze_panes = "A9"
    sheet.row_dimensions[1].height = 30
    _merge_value(sheet, "A1:G1", "CUENTAS UTILIZADAS EN LA JORNADA",
                 fill=PatternFill("solid", fgColor=NAVY), font=Font(color=WHITE, bold=True, size=16),
                 alignment=Alignment(horizontal="center", vertical="center"))
    _merge_value(sheet, "A2:G2", "Compras activas y abonos aplicados · importes en USD",
                 font=Font(color=GRAY, italic=True), alignment=Alignment(horizontal="center"))
    _label(sheet, "A3", "JORNADA")
    _merge_value(sheet, "B3:D3", journey["name"], font=Font(bold=True))
    _label(sheet, "E3", "FECHA DE CORTE")
    _merge_value(sheet, "F3:G3", generated_on)
    sheet["F3"].number_format = "dd/mm/yyyy"
    _label(sheet, "A4", "RESPONSABLE")
    _merge_value(sheet, "B4:D4", owner_name)
    _label(sheet, "E4", "CUENTAS UTILIZADAS")
    _merge_value(sheet, "F4:G4", len(accounts))

    purchases_total = sum(account["purchases_total"] for account in accounts)
    received_total = sum(account["received_total"] for account in accounts)
    cards = (
        ("A6:C6", "A7:C7", "TOTAL DE COMPRAS", purchases_total, NAVY),
        ("E6:G6", "E7:G7", "TOTAL RECIBIDO", received_total, GREEN),
    )
    for label_range, value_range, label, cents, color in cards:
        _merge_value(sheet, label_range, label, fill=PatternFill("solid", fgColor=LIGHT_BLUE),
                     font=Font(size=9, bold=True, color=NAVY), alignment=Alignment(horizontal="center"))
        cell = _merge_value(sheet, value_range, _dollars(cents), fill=PatternFill("solid", fgColor="F8FAFC"),
                            font=Font(size=14, bold=True, color=color), alignment=Alignment(horizontal="center"))
        cell.number_format = MONEY_FORMAT

    headers = ("Cuenta", "Tipo", "Estado", "Compras", "Total compras", "Abonos", "Total recibido")
    for column, title in enumerate(headers, 1):
        cell = sheet.cell(8, column, title)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.font = Font(color=WHITE, bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    kind_labels = {"card": "Tarjeta", "cash": "Efectivo", "transfer": "Transferencia", "other": "Otra"}
    start_row = 9
    for row_number, account in enumerate(accounts, start_row):
        state = "Histórica" if account["active"] is None else ("Activa" if account["active"] else "Desactivada")
        values = (account["label"], kind_labels.get(account["kind"], "Sin clasificar"), state,
                  account["purchase_count"], _dollars(account["purchases_total"]),
                  account["receipt_count"], _dollars(account["received_total"]))
        for column, value in enumerate(values, 1):
            cell = sheet.cell(row_number, column, value)
            cell.border = Border(bottom=THIN)
            cell.alignment = Alignment(vertical="center", wrap_text=column == 1, indent=1 if column == 1 else 0,
                                       horizontal="center" if column in (2, 3, 4, 6) else None)
        for column in (5, 7):
            sheet.cell(row_number, column).number_format = MONEY_FORMAT
    if accounts:
        total_row = start_row + len(accounts)
    else:
        _merge_value(sheet, "A9:G9", "Sin cuentas utilizadas en esta jornada.",
                     font=Font(color=GRAY, italic=True), alignment=Alignment(horizontal="center"))
        total_row = 10
    _merge_value(sheet, f"A{total_row}:C{total_row}", "TOTALES",
                 fill=PatternFill("solid", fgColor=LIGHT_BLUE), font=Font(bold=True, color=NAVY),
                 alignment=Alignment(horizontal="center"))
    sheet.cell(total_row, 4, sum(account["purchase_count"] for account in accounts))
    _money(sheet, f"E{total_row}", purchases_total, bold=True)
    sheet.cell(total_row, 6, sum(account["receipt_count"] for account in accounts))
    _money(sheet, f"G{total_row}", received_total, bold=True)
    for column in range(4, 8):
        sheet.cell(total_row, column).fill = PatternFill("solid", fgColor=LIGHT_BLUE)
    widths = (34, 18, 16, 12, 18, 12, 18)
    for column, width in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(column)].width = width
    sheet.auto_filter.ref = f"A8:G{max(8, start_row + len(accounts) - 1)}"
    sheet.print_title_rows = "1:8"
    sheet.print_area = f"A1:G{total_row}"
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.sheet_properties.pageSetUpPr.fitToPage = True


def _build_consolidated(sheet, journey, billings, owner_name, generated_on):
    month_names = ("", "enero", "febrero", "marzo", "abril", "mayo", "junio",
                   "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre")
    journey_date = date.fromisoformat(journey["date"])
    rows = []
    for billing in billings:
        purchases_total = billing["subtotal"] + billing["tax"]
        # El consolidado incluye el envío internacional, pero no cargos locales.
        invoiced = purchases_total + billing["commission"] + billing["shipping"]
        raw_balance = invoiced - billing["paid"]
        debtor_balance = max(raw_balance, 0)
        rows.append({
            "billing": billing,
            "purchases_total": purchases_total,
            "invoiced": invoiced,
            "debtor_balance": debtor_balance,
            "raw_balance": raw_balance,
        })
    portfolio_total = sum(row["debtor_balance"] for row in rows)
    purchases_total = sum(row["purchases_total"] for row in rows)
    commissions_total = sum(row["billing"]["commission"] for row in rows)
    paid_total = sum(row["billing"]["paid"] for row in rows)

    sheet.sheet_view.showGridLines = False
    sheet.freeze_panes = "A10"
    sheet.row_dimensions[1].height = 30
    _merge_value(sheet, "A1:K1", "ESTADO CONSOLIDADO DE CARTERA Y LIQUIDACIONES",
                 fill=PatternFill("solid", fgColor=NAVY), font=Font(color=WHITE, bold=True, size=16),
                 alignment=Alignment(horizontal="center", vertical="center"))
    _merge_value(sheet, "A2:K2", "Control consolidado de clientes y cobranza por jornada",
                 font=Font(color=GRAY, italic=True), alignment=Alignment(horizontal="center"))

    _label(sheet, "A3", "REPORTE / CARTERA")
    _merge_value(sheet, "B3:D3", "Consolidado General de Clientes")
    _label(sheet, "E3", "FECHA DE CORTE")
    _merge_value(sheet, "F3:G3", generated_on)
    sheet["F3"].number_format = "dd/mm/yyyy"
    _label(sheet, "H3", "MONEDA OFICIAL")
    _merge_value(sheet, "I3:K3", "USD ($) · Dólares estadounidenses")
    _label(sheet, "A4", "ENTIDAD EMISORA")
    _merge_value(sheet, "B4:D4", owner_name)
    _label(sheet, "E4", "PERÍODO")
    _merge_value(sheet, "F4:G4", f"{month_names[journey_date.month].capitalize()} {journey_date.year}")
    _label(sheet, "H4", "CUENTAS TOTALES")
    _merge_value(sheet, "I4:K4", f"{len(rows)} {'cliente' if len(rows) == 1 else 'clientes'}")

    cards = [
        ("A6:B6", "A7:B7", "VOLUMEN TOTAL COMPRAS", purchases_total, NAVY),
        ("C6:D6", "C7:D7", "COMISIONES TOTALES", commissions_total, NAVY),
        ("E6:F6", "E7:F7", "TOTAL RECAUDADO (ABONOS)", paid_total, GREEN),
        ("G6:I6", "G7:I7", "SALDO DEUDOR DE CARTERA", portfolio_total, "C62828"),
    ]
    for label_range, value_range, label, cents, color in cards:
        _merge_value(sheet, label_range, label, fill=PatternFill("solid", fgColor=LIGHT_BLUE),
                     font=Font(size=9, bold=True, color=NAVY), alignment=Alignment(horizontal="center"))
        cell = _merge_value(sheet, value_range, _dollars(cents), fill=PatternFill("solid", fgColor="F8FAFC"),
                            font=Font(size=14, bold=True, color=color), alignment=Alignment(horizontal="center"))
        cell.number_format = MONEY_FORMAT

    headers = ("Folio liquidación", "Cliente / deudor", "Subtotal ($)", "Tax", "Total compras",
               "Comisión gestión", "Envío internacional", "Total facturado", "Abono / pagado",
               "Saldo deudor", "Productos pendientes")
    for column, title in enumerate(headers, 1):
        cell = sheet.cell(9, column, title)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.font = Font(color=WHITE, bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    sheet.row_dimensions[9].height = 32

    start_row = 10
    for row_number, data in enumerate(rows, start_row):
        billing = data["billing"]
        values = (
            _folio(billing, journey), billing["client_name"], _dollars(billing["subtotal"]),
            _dollars(billing["tax"]), _dollars(data["purchases_total"]), _dollars(billing["commission"]),
            _dollars(billing["shipping"]), _dollars(data["invoiced"]), _dollars(billing["paid"]),
            _dollars(data["debtor_balance"]), billing["pending_units"],
        )
        for column, value in enumerate(values, 1):
            cell = sheet.cell(row_number, column, value)
            cell.border = Border(bottom=THIN, right=THIN)
            cell.alignment = Alignment(vertical="center", wrap_text=column == 2,
                                       indent=1 if column == 2 else 0,
                                       horizontal="center" if column in (1, 11) else None)
        for column in range(3, 11):
            sheet.cell(row_number, column).number_format = MONEY_FORMAT

    total_row = start_row + len(rows)
    _merge_value(sheet, f"A{total_row}:B{total_row}", "TOTALES GENERALES",
                 fill=PatternFill("solid", fgColor=LIGHT_BLUE), font=Font(bold=True, color=NAVY),
                 alignment=Alignment(horizontal="center"))
    totals = (
        sum(row["billing"]["subtotal"] for row in rows),
        sum(row["billing"]["tax"] for row in rows), purchases_total, commissions_total,
        sum(row["billing"]["shipping"] for row in rows), sum(row["invoiced"] for row in rows),
        paid_total, portfolio_total,
    )
    for column, cents in enumerate(totals, 3):
        _money(sheet, f"{get_column_letter(column)}{total_row}", cents, bold=True)
        sheet.cell(total_row, column).fill = PatternFill("solid", fgColor=LIGHT_BLUE)
    sheet.cell(total_row, 11, sum(row["billing"]["pending_units"] for row in rows))
    sheet.cell(total_row, 11).font = Font(bold=True)
    sheet.cell(total_row, 11).fill = PatternFill("solid", fgColor=LIGHT_BLUE)

    widths = (20, 28, 15, 13, 16, 18, 19, 17, 17, 17, 18)
    for column, width in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(column)].width = width
    sheet.auto_filter.ref = f"A9:K{max(9, total_row - 1)}"
    sheet.print_title_rows = "1:9"
    sheet.print_area = f"A1:K{total_row}"
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.sheet_properties.pageSetUpPr.fitToPage = True


def _build_summary(sheet, billing, journey, purchases, generated_on):
    report_total = billing["total"] - billing["local_charge"]
    report_balance = report_total - billing["paid"]
    sheet.sheet_view.showGridLines = False
    sheet.freeze_panes = "A11"
    sheet.row_dimensions[1].height = 30
    _merge_value(sheet, "A1:K1", "ESTADO DE CUENTA Y LIQUIDACIÓN DE COMPRAS",
                 fill=PatternFill("solid", fgColor=NAVY), font=Font(color=WHITE, bold=True, size=16),
                 alignment=Alignment(horizontal="center", vertical="center"))
    _merge_value(sheet, "A2:K2", "Reporte por cliente · importes en dólares estadounidenses (USD)",
                 font=Font(color=GRAY, italic=True), alignment=Alignment(horizontal="center"))

    _label(sheet, "A3", "CLIENTE")
    _merge_value(sheet, "B3:E3", billing["client_name"], font=Font(bold=True))
    _label(sheet, "F3", "FOLIO")
    _merge_value(sheet, "G3:H3", _folio(billing, journey), font=Font(bold=True))
    _label(sheet, "I3", "EMITIDO")
    _merge_value(sheet, "J3:K3", generated_on)
    sheet["J3"].number_format = "dd/mm/yyyy"
    _label(sheet, "A4", "JORNADA")
    _merge_value(sheet, "B4:E4", journey["name"])
    _label(sheet, "F4", "ESTADO")
    _merge_value(sheet, "G4:H4", "Provisional" if billing["provisional"] or journey["status"] != "cerrada" else "Cerrado")
    _label(sheet, "I4", "PRODUCTOS PENDIENTES")
    _merge_value(sheet, "J4:K4", f'{billing["pending_units"]} unidades', font=Font(bold=True))

    cards = [
        ("A6:B6", "A7:B7", "COMPRAS + TAX", billing["subtotal"] + billing["tax"]),
        ("D6:E6", "D7:E7", "COMISIÓN", billing["commission"]),
        ("G6:H6", "G7:H7", "PAGOS APLICADOS", billing["paid"]),
        ("J6:K6", "J7:K7", "SALDO", report_balance),
    ]
    for label_range, value_range, label, cents in cards:
        _merge_value(sheet, label_range, label, fill=PatternFill("solid", fgColor=LIGHT_BLUE),
                     font=Font(size=9, bold=True, color=NAVY), alignment=Alignment(horizontal="center"))
        cell = _merge_value(sheet, value_range, _dollars(cents), fill=PatternFill("solid", fgColor=LIGHT_GREEN),
                            font=Font(size=14, bold=True, color=GREEN), alignment=Alignment(horizontal="center"))
        cell.number_format = MONEY_FORMAT

    for column, title in enumerate(("Fecha", "Tienda / cuenta usada", "Productos", "Tax", "Comisión", "Total con comisión"), 1):
        cell = sheet.cell(10, column, title)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.font = Font(color=WHITE, bold=True)
        cell.alignment = Alignment(horizontal="center")
    _header(sheet, "G10:J10", "LIQUIDACIÓN")
    _header(sheet, "K10:K10", "IMPORTE")

    start_row = 11
    for row, purchase in enumerate(purchases, start_row):
        sheet.cell(row, 1, date.fromisoformat(purchase["date"]))
        sheet.cell(row, 1).number_format = "dd/mm/yyyy"
        sheet.cell(row, 2, f'{purchase["store_name"]}\n{purchase["payment_account_label"]}')
        sheet.cell(row, 2).alignment = Alignment(indent=1,wrap_text=True)
        _money(sheet, f"C{row}", purchase["subtotal"])
        _money(sheet, f"D{row}", purchase["tax"])
        _money(sheet, f"E{row}", purchase["commission"])
        _money(sheet, f"F{row}", purchase["charged_total"])
        for column in range(1, 7):
            sheet.cell(row, column).border = Border(bottom=THIN)
    if not purchases:
        _merge_value(sheet, "A11:F11", "Sin compras activas en este cobro.", font=Font(color=GRAY, italic=True))

    concepts = [
        ("Productos", billing["subtotal"]),
        ("Tax", billing["tax"]),
        ("Comisiones registradas por compra", billing["commission"]),
        ("Envío internacional", billing["shipping"]),
        ("Total facturado", report_total),
        ("Pagos aplicados", -billing["paid"]),
        ("Saldo", report_balance),
    ]
    for row, (label, cents) in enumerate(concepts, start_row):
        _merge_value(sheet, f"G{row}:J{row}", label)
        _money(sheet, f"K{row}", cents, bold=label in ("Total facturado", "Saldo"))
        for column in range(7, 12):
            sheet.cell(row, column).border = Border(bottom=THIN)

    note_row = max(start_row + len(purchases), start_row + len(concepts)) + 2
    _merge_value(sheet, f"A{note_row}:K{note_row}",
                 "Los pagos se aplican al cobro consolidado del cliente; no se distribuyen artificialmente entre compras.",
                 fill=PatternFill("solid", fgColor=LIGHT_BLUE), font=Font(size=9, color=NAVY),
                 alignment=Alignment(wrap_text=True))
    _merge_value(sheet, f"A{note_row + 1}:K{note_row + 1}",
                 "El tax corresponde a la tasa guardada en cada compra. Este archivo refleja el estado de la liquidación al momento de generarlo.",
                 font=Font(size=9, color=GRAY, italic=True), alignment=Alignment(wrap_text=True))

    widths = {"A": 13, "B": 26, "C": 15, "D": 13, "E": 16, "F": 12, "G": 17, "H": 13, "I": 13, "J": 16, "K": 17}
    for column, width in widths.items():
        sheet.column_dimensions[column].width = width
    sheet.auto_filter.ref = f"A10:F{max(10, start_row + len(purchases) - 1)}"
    sheet.print_title_rows = "1:10"
    sheet.print_area = f"A1:K{note_row + 1}"
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.sheet_properties.pageSetUpPr.fitToPage = True


def _build_details(sheet, billing, journey, purchases):
    sheet.sheet_view.showGridLines = False
    sheet.freeze_panes = "A6"
    sheet.row_dimensions[1].height = 30
    _merge_value(sheet, "A1:J1", "DETALLE AUDITADO DE COMPRAS Y ARTÍCULOS",
                 fill=PatternFill("solid", fgColor=NAVY), font=Font(color=WHITE, bold=True, size=16),
                 alignment=Alignment(horizontal="center", vertical="center"))
    _merge_value(sheet, "A2:J2", "Las compras anuladas no forman parte de los importes.",
                 font=Font(color=GRAY, italic=True), alignment=Alignment(horizontal="center"))
    _label(sheet, "A3", "CLIENTE")
    _merge_value(sheet, "B3:D3", billing["client_name"], font=Font(bold=True))
    _label(sheet, "E3", "JORNADA")
    _merge_value(sheet, "F3:J3", journey["name"])
    _label(sheet, "A4", "FOLIO")
    _merge_value(sheet, "B4:D4", _folio(billing, journey))
    _label(sheet, "E4", "MONEDA")
    _merge_value(sheet, "F4:J4", "USD", font=Font(bold=True))

    headers = ("Fecha", "Tienda / cuenta usada", "Descripción", "Cantidad", "Precio unitario", "Subtotal compra", "Tax", "Comisión %", "Comisión", "Total con comisión")
    for column, title in enumerate(headers, 1):
        cell = sheet.cell(5, column, title)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.font = Font(color=WHITE, bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    row = 6
    for purchase in purchases:
        for item_index, item in enumerate(purchase["items"]):
            sheet.cell(row, 1, date.fromisoformat(purchase["date"]))
            sheet.cell(row, 1).number_format = "dd/mm/yyyy"
            sheet.cell(row, 2, f'{purchase["store_name"]}\n{purchase["payment_account_label"]}' if item_index == 0 else "")
            sheet.cell(row, 3, item["description"])
            sheet.cell(row, 4, item["quantity"])
            _money(sheet, f"E{row}", item["price"])
            if item_index == 0:
                _money(sheet, f"F{row}", purchase["subtotal"])
                _money(sheet, f"G{row}", purchase["tax"])
                sheet.cell(row, 8, purchase["rate"] / 10000)
                sheet.cell(row, 8).number_format = "0.00%"
                _money(sheet, f"I{row}", purchase["commission"])
                _money(sheet, f"J{row}", purchase["charged_total"])
            for column in range(1, 11):
                sheet.cell(row, column).border = Border(bottom=THIN)
                sheet.cell(row, column).alignment = Alignment(vertical="top", wrap_text=column in (2, 3), indent=1 if column in (2, 3) else 0)
            row += 1
    if row == 6:
        _merge_value(sheet, "A6:J6", "Sin artículos activos para mostrar.", font=Font(color=GRAY, italic=True))
        row += 1

    sheet.cell(row, 1, "TOTALES")
    sheet.cell(row, 1).font = Font(bold=True, color=WHITE)
    sheet.cell(row, 1).fill = PatternFill("solid", fgColor=GREEN)
    for column in range(2, 6):
        sheet.cell(row, column).fill = PatternFill("solid", fgColor=GREEN)
    _money(sheet, f"F{row}", billing["subtotal"], bold=True)
    _money(sheet, f"G{row}", billing["tax"], bold=True)
    sheet.cell(row, 8, "—")
    _money(sheet, f"I{row}", billing["commission"], bold=True)
    _money(sheet, f"J{row}", billing["subtotal"] + billing["tax"] + billing["commission"], bold=True)
    for column in range(6, 11):
        sheet.cell(row, column).fill = PatternFill("solid", fgColor=LIGHT_GREEN)

    widths = (13, 24, 38, 11, 16, 17, 13, 13, 15, 19)
    for column, width in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(column)].width = width
    sheet.auto_filter.ref = f"A5:H{max(5, row - 1)}"
    sheet.print_title_rows = "1:5"
    sheet.print_area = f"A1:J{row}"
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.sheet_properties.pageSetUpPr.fitToPage = True
