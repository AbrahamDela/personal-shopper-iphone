PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS clients (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), name TEXT NOT NULL,
 phone TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '', rate INTEGER NOT NULL CHECK(rate BETWEEN 0 AND 10000),
 UNIQUE(id,owner_id)
);
CREATE TABLE IF NOT EXISTS journeys (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), name TEXT NOT NULL, date TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'abierta' CHECK(status IN ('abierta','cerrada')), UNIQUE(id,owner_id)
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), name TEXT NOT NULL,
 UNIQUE(owner_id,name), UNIQUE(id,owner_id)
);
CREATE TABLE IF NOT EXISTS stores (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), name TEXT NOT NULL,
 UNIQUE(owner_id,name), UNIQUE(id,owner_id)
);
CREATE TABLE IF NOT EXISTS accounts (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), name TEXT NOT NULL,
 currency TEXT NOT NULL CHECK(currency IN ('USD','NIO','EUR')),
 UNIQUE(owner_id,name,currency), UNIQUE(id,owner_id,currency)
);
CREATE TABLE IF NOT EXISTS purchases (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), journey_id INTEGER NOT NULL,
 client_id INTEGER NOT NULL, store_id INTEGER NOT NULL, date TEXT NOT NULL,
 currency TEXT NOT NULL CHECK(currency IN ('USD','NIO','EUR')),
 rate INTEGER NOT NULL CHECK(rate BETWEEN 0 AND 10000),
 shipping INTEGER NOT NULL CHECK(shipping>=0), shipping_cost INTEGER NOT NULL CHECK(shipping_cost>=0),
 reference TEXT NOT NULL DEFAULT '', order_note TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(id,owner_id), UNIQUE(id,owner_id,client_id,currency),
 FOREIGN KEY(journey_id,owner_id) REFERENCES journeys(id,owner_id),
 FOREIGN KEY(client_id,owner_id) REFERENCES clients(id,owner_id),
 FOREIGN KEY(store_id,owner_id) REFERENCES stores(id,owner_id)
);
CREATE TABLE IF NOT EXISTS items (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, purchase_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
 description TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 10000),
 price INTEGER NOT NULL CHECK(price BETWEEN 0 AND 100000000), UNIQUE(id,owner_id),
 FOREIGN KEY(purchase_id,owner_id) REFERENCES purchases(id,owner_id),
 FOREIGN KEY(product_id,owner_id) REFERENCES products(id,owner_id)
);
CREATE TABLE IF NOT EXISTS receipts (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), client_id INTEGER NOT NULL,
 account_id INTEGER NOT NULL, date TEXT NOT NULL, currency TEXT NOT NULL CHECK(currency IN ('USD','NIO','EUR')),
 amount INTEGER NOT NULL CHECK(amount>0 AND amount<=100000000), reference TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(id,owner_id,client_id,currency),
 FOREIGN KEY(client_id,owner_id) REFERENCES clients(id,owner_id),
 FOREIGN KEY(account_id,owner_id,currency) REFERENCES accounts(id,owner_id,currency)
);
CREATE TABLE IF NOT EXISTS allocations (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, client_id INTEGER NOT NULL, currency TEXT NOT NULL,
 receipt_id INTEGER NOT NULL, purchase_id INTEGER NOT NULL, amount INTEGER NOT NULL CHECK(amount>0),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(receipt_id,owner_id,client_id,currency) REFERENCES receipts(id,owner_id,client_id,currency),
 FOREIGN KEY(purchase_id,owner_id,client_id,currency) REFERENCES purchases(id,owner_id,client_id,currency)
);
CREATE TABLE IF NOT EXISTS deliveries (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, item_id INTEGER NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity>0), date TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(item_id,owner_id) REFERENCES items(id,owner_id)
);
CREATE TABLE IF NOT EXISTS audit (
 id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), entity TEXT NOT NULL,
 entity_id INTEGER NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS purchase_owner ON purchases(owner_id,client_id,journey_id);
CREATE INDEX IF NOT EXISTS receipt_owner ON receipts(owner_id,client_id);
CREATE INDEX IF NOT EXISTS allocation_purchase ON allocations(purchase_id,owner_id);
CREATE INDEX IF NOT EXISTS allocation_receipt ON allocations(receipt_id,owner_id);
CREATE INDEX IF NOT EXISTS delivery_item ON deliveries(item_id,owner_id);
CREATE TRIGGER IF NOT EXISTS delivery_limit BEFORE INSERT ON deliveries BEGIN
 SELECT CASE WHEN NEW.quantity + COALESCE((SELECT SUM(quantity) FROM deliveries WHERE item_id=NEW.item_id),0)
 > (SELECT quantity FROM items WHERE id=NEW.item_id) THEN RAISE(ABORT,'Entrega excesiva') END;
END;
CREATE TRIGGER IF NOT EXISTS receipt_limit BEFORE INSERT ON allocations BEGIN
 SELECT CASE WHEN NEW.amount + COALESCE((SELECT SUM(amount) FROM allocations WHERE receipt_id=NEW.receipt_id),0)
 > (SELECT amount FROM receipts WHERE id=NEW.receipt_id) THEN RAISE(ABORT,'Crédito insuficiente') END;
 SELECT CASE WHEN NEW.amount + COALESCE((SELECT SUM(amount) FROM allocations WHERE purchase_id=NEW.purchase_id),0)
 > (SELECT subtotal + (subtotal*rate+5000)/10000 + shipping FROM
 (SELECT p.rate,p.shipping,SUM(i.quantity*i.price) AS subtotal FROM purchases p JOIN items i ON i.purchase_id=p.id WHERE p.id=NEW.purchase_id GROUP BY p.id))
 THEN RAISE(ABORT,'Aplicación excesiva') END;
END;
PRAGMA user_version = 1;
